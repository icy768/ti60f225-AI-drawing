/* Host harness for the same parser used by the embedded firmware. */
#include <stdio.h>
#include <stdint.h>
#include "c48_package.h"
typedef struct {FILE *in,*out;unsigned count;} context;
static int read_byte(void *p){return fgetc(((context *)p)->in);}
static int write_record(void *p,uint32_t a,uint32_t lo,uint32_t hi){
    context *c=(context *)p;c->count++;
    if(c->out)fprintf(c->out,"%08x %08x %02x\n",a,lo,hi);
    return 0;
}
int main(int argc,char **argv){
    context c={0};c48_package_info validated,loaded;int r;
    if(argc<2)return 2;
    c.in=fopen(argv[1],"rb");if(!c.in)return 3;
    r=c48_package_pass(&c,read_byte,0,0,&validated);
    if(r>0 && fgetc(c.in)!=EOF)r=-1;
    if(r>0){
        rewind(c.in);
        if(argc>2){c.out=fopen(argv[2],"w");if(!c.out){fclose(c.in);return 3;}}
        r=c48_package_pass(&c,read_byte,write_record,&validated,&loaded);
    }
    if(c.out)fclose(c.out);
    fclose(c.in);
    printf("result=%d written=%u\n",r,c.count);
    return r>0?0:1;
}
