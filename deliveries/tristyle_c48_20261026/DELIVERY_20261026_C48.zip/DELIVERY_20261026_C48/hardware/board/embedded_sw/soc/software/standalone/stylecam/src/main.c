/*
 * StyleCam RISC-V control firmware (Sapphire RV32I, 16 KB on-chip RAM)
 *
 * - 权重加载：开机经 SPI0 从配置 Flash 0x200000 读出权重包（model/net_blob.bin，CRC32 校验），
 *   逐条写入加速器的权重 / requant 系数 RAM（位流里不含权重）
 * - SC431HAI 初始化：通过 APB 下发 I2C 寄存器命令，时序与表格同原 RTL 状态机（rtl/sc431hai/sc_sequence.vh）
 * - 加速器调度：每帧由 CPU 下发单步启动，帧发布中断里统计帧率并下发下一帧
 * - 风格部署：开机依次触发三种风格的单遍预热，之后切换风格无需等待
 * - 交互：KEY3 短按切风格、长按切布局；串口 0 1 2 / v 同样可操作；OSD 叠加状态
 * - 语音（创意交互，编译期开关默认关闭）：语音模块经 ESP32-S3 映射成单字符即可，无需改本文件；
 *   若语音模块直连 uart_rx，用 -DSTYLECAM_VOICE_TOKENS=1 打开 't' 关键词模式（见下方 console）
 */
#include <stdint.h>
#include "bsp.h"
#include "plic.h"
#include "clint.h"
#include "riscv.h"
#include "uart.h"
#include "spi.h"
#include "spiFlash.h"
#include "stylecam_regs.h"
#include "sc431hai_seq.h"
#include "c48_package.h"
#define BLOB_FLASH_ADDR 0x200000u
static c48_package_info loaded_package;

#define FLASH_SPI SYSTEM_SPI_0_IO_CTRL

void trap_entry();
void main();

static const char *const STYLE_NAME[3] = {"FAUVISM", "VAN GOGH", "PENCIL"};
static const char *const VIEW_NAME[3] = {"ORIGINAL | STYLIZED", "STYLIZED FULL", "ORIGINAL FULL"};

static volatile uint32_t ctrl;           /* CTRL 影子（不含 STEP） */
static volatile uint32_t streaming;      /* 1: 发布中断里自动下发下一帧 */
static volatile uint32_t frames;         /* 已发布帧数 */
static volatile uint32_t last_pub_t;     /* 最近一次发布的时刻（100 MHz 计数） */
static volatile uint32_t job_cycles, job_max, pass_cycles;  /* 刚完成那帧：作业总周期、运行中最大值、最后一遍网络 */
static volatile uint32_t key3_count, key0_count, error_count;
static volatile uint32_t switch_pending, switch_style, switch_t0, switch_us_last, switch_us_max;
static volatile uint32_t first_cycles, input_stall_cycles, output_stall_cycles;
static volatile uint32_t scan_pending, scan_t0, scan_after, scan_us_last, scan_us_max;
static volatile uint32_t osd_dirty;

static inline uint32_t now(void) { return (uint32_t)clint_getTime(BSP_CLINT); }       /* 100 MHz */
static inline uint32_t us_since(uint32_t t0) { return (now() - t0) / (BSP_CLINT_HZ / 1000000); }
static void delay_ms(uint32_t ms) { while (ms--) bsp_uDelay(1000); }

static void ctrl_write(uint32_t v) { ctrl = v; SC_CTRL = v; }
static void step_frame(void) { SC_CTRL = ctrl | CTRL_STEP; }
static uint32_t cur_style(void) { return (ctrl >> 4) & 3; }
static uint32_t cur_view(void) { return (ctrl >> 8) & 3; }

static void mark_switch(uint32_t style)
{
    switch_style = style; switch_t0 = now(); switch_pending = 1;
    scan_t0 = SC_CLOCK_CYCLES; scan_after = SC_PROCESSED; scan_pending = 1;
}

/* Timestamp is captured in hardware at scan retirement, before visible pixels.
 * Polling latency is excluded; do not label this camera-to-photon latency. */
static void poll_scan(void)
{
    csr_clear(mstatus, MSTATUS_MIE);
    uint32_t seq = SC_SCAN_SEQUENCE;
    uint32_t style = SC_SCAN_STYLE, stamp = SC_SCAN_TIMESTAMP;
    if (scan_pending && seq != scan_after && (seq - scan_after) < 0x80000000u &&
        style == switch_style && seq == SC_SCAN_SEQUENCE) {
        uint32_t delta = stamp - scan_t0;
        if (delta < 0x80000000u) {
            scan_us_last = delta / 100u;
            if (scan_us_last > scan_us_max) scan_us_max = scan_us_last;
            scan_pending = 0;
        }
    }
    csr_set(mstatus, MSTATUS_MIE);
}

/* ---------------- OSD ---------------- */
/* 每行先在缓冲里拼好（0 = 透明），再整行一次写出，避免先清后画造成闪烁 */
static uint8_t rb[OSD_COLS];
static void row_begin(void) { for (int c = 0; c < OSD_COLS; c++) rb[c] = 0; }
static void row_put(int col, const char *s, int hi)
{
    for (; *s && col < OSD_COLS; s++, col++) rb[col] = (uint8_t)*s | (hi ? OSD_HI : 0);
}
static int slen(const char *s) { int n = 0; while (s[n]) n++; return n; }
static void row_center(int center, const char *s, int hi) { row_put(center - slen(s) / 2, s, hi); }
static void row_flush(int row) { for (int c = 0; c < OSD_COLS; c++) SC_OSD(row * OSD_COLS + c) = rb[c]; }
static void osd_clear_all(void) { row_begin(); for (int r = 0; r < OSD_ROWS; r++) row_flush(r); }

/* 无除法器：小整数格式化 */
static char *fmt_u(char *p, uint32_t v)
{
    char t[10]; int n = 0;
    do { t[n++] = '0' + v % 10; v /= 10; } while (v);
    while (n) *p++ = t[--n];
    *p = 0;
    return p;
}
static char *fmt_x10(char *p, uint32_t v)   /* 153 -> "15.3" */
{
    p = fmt_u(p, v / 10);
    *p++ = '.'; *p++ = '0' + v % 10; *p = 0;
    return p;
}
static char *cat(char *p, const char *s) { while (*s) *p++ = *s++; *p = 0; return p; }

static uint32_t fps_x10, fps_x100, cam_fps_x10, nn_ms_x10;
#define KEY3_HOLD_US 700000u
static volatile uint32_t key3_press_t;
static volatile uint8_t key3_wait_release, key3_long_done;
static uint32_t stream_skip_base;

static void osd_draw(void)
{
    char line[OSD_COLS + 1], *p;
    uint32_t view = cur_view(), style = cur_style();
    row_begin();
    row_put(1, "StyleCam  RISC-V + FPGA", 1);
    p = cat(line, "FPS "); fmt_x10(p, fps_x10);
    row_put(64, line, 1);
    row_flush(0);
    row_begin();
    if (view == 0) {
        row_center(20, "ORIGINAL", 0);
        p = cat(line, "STYLIZED - "); cat(p, STYLE_NAME[style]);
        row_center(60, line, 0);
    }
    row_flush(2);
    row_begin();
    p = cat(line, "STYLE "); p = cat(p, STYLE_NAME[style]);
    p = cat(p, "   NN "); p = fmt_x10(p, nn_ms_x10); p = cat(p, " ms   CAM "); p = fmt_x10(p, cam_fps_x10);
    p = cat(p, " fps   VIEW "); cat(p, VIEW_NAME[view]);
    row_put(1, line, 0);
    row_flush(20);
    row_begin();
    row_flush(21);
    row_begin();
    row_flush(22);
}

static void osd_message(const char *msg)
{
    row_begin(); row_put(1, msg, 1); row_flush(20);
}

/* ---------------- 中断 ---------------- */
static void on_irq(uint32_t pend)
{
    if (pend & IRQ_PUBLISH) {
        last_pub_t = now();
        frames++;
        /* 作业计数器在下一帧启动时清零，发布时读到的是刚完成那帧的总耗时 */
        job_cycles = SC_JOB_CYCLES;
        pass_cycles = SC_RUN_CYCLES;
        first_cycles = SC_FIRST_OUTPUT;
        input_stall_cycles = SC_INPUT_STALLS;
        output_stall_cycles = SC_OUTPUT_STALLS;
        if (streaming && job_cycles > job_max) job_max = job_cycles;
        if (switch_pending && ST_ENGINE_STYLE(SC_STATUS) == switch_style) {
            uint32_t us = us_since(switch_t0);
            switch_us_last = us;
            if (us > switch_us_max) switch_us_max = us;
            switch_pending = 0;
        }
        if (streaming) step_frame();          /* 启动下一帧 */
    }
    if (pend & IRQ_KEY3) {
        key3_count++;
        key3_press_t = now();
        key3_wait_release = 1;
        key3_long_done = 0;
    }
    if (pend & IRQ_KEY2) {
        key0_count++; /* Legacy IRQ_KEY2 now comes from the physical K0 button. */
        uint32_t v = cur_view() == 2 ? 0 : cur_view() + 1;
        ctrl_write((ctrl & ~CTRL_VIEW(3)) | CTRL_VIEW(v));
        osd_dirty = 1;
    }
    if (pend & IRQ_ERROR) {
        error_count++;
        if (streaming) step_frame();          /* 出错帧已释放，继续 */
    }
}

/* KEY3 is the verified physical button. Defer its short action until release,
 * allowing a hold to select the layout without also changing style. */
static void poll_key3(void)
{
    if (!key3_wait_release) return;
    uint32_t down = (SC_STATUS >> 27) & 1u;
    if (down && !key3_long_done && us_since(key3_press_t) >= KEY3_HOLD_US) {
        uint32_t v = cur_view() == 2 ? 0 : cur_view() + 1;
        ctrl_write((ctrl & ~CTRL_VIEW(3)) | CTRL_VIEW(v));
        key3_long_done = 1;
        osd_dirty = 1;
    }
    if (!down) {
        if (!key3_long_done) {
            uint32_t s = cur_style() == 2 ? 0 : cur_style() + 1;
            ctrl_write((ctrl & ~CTRL_STYLE(3)) | CTRL_STYLE(s));
            mark_switch(s);
            osd_dirty = 1;
        }
        key3_wait_release = 0;
    }
}

void trap()
{
    int32_t mcause = csr_read(mcause);
    if (mcause < 0 && (mcause & 0xF) == CAUSE_MACHINE_EXTERNAL) {
        uint32_t claim;
        while ((claim = plic_claim(BSP_PLIC, BSP_PLIC_CPU_0))) {
            if (claim == SYSTEM_PLIC_USER_INTERRUPT_A_INTERRUPT) {
                uint32_t pend;
                while ((pend = SC_IRQ_PEND)) { SC_IRQ_PEND = pend; on_irq(pend); }
            }
            plic_release(BSP_PLIC, BSP_PLIC_CPU_0, claim);
        }
    } else {
        bsp_printf("\r\n*** TRAP mcause=%x mepc=%x ***\r\n", mcause, csr_read(mepc));
        while (1);
    }
}

static void irq_init(void)
{
    SC_IRQ_PEND = 0xF;
    SC_IRQ_EN = IRQ_PUBLISH | IRQ_KEY3 | IRQ_KEY2 | IRQ_ERROR;
    plic_set_threshold(BSP_PLIC, BSP_PLIC_CPU_0, 0);
    plic_set_enable(BSP_PLIC, BSP_PLIC_CPU_0, SYSTEM_PLIC_USER_INTERRUPT_A_INTERRUPT, 1);
    plic_set_priority(BSP_PLIC, SYSTEM_PLIC_USER_INTERRUPT_A_INTERRUPT, 1);
    csr_write(mtvec, trap_entry);
    csr_set(mie, MIE_MEIE);
    csr_write(mstatus, csr_read(mstatus) | MSTATUS_MPP | MSTATUS_MIE);
}

/* ---------------- SC431HAI 驱动 ---------------- */
/* 返回 1 成功，2 NACK，4 超时 */
static int i2c_xfer(uint16_t reg, uint8_t wdata, int read, uint8_t *rdata)
{
    SC_I2C_CMD = (uint32_t)reg | ((uint32_t)wdata << 16) | (read ? (1u << 24) : 0);
    uint32_t t0 = now(), st;
    do {
        st = SC_I2C_STAT;
        if (us_since(t0) > 50000) return 4;
    } while ((st & 1) || !(st & (1u << 16)));
    if (rdata) *rdata = (st >> 8) & 0xFF;
    return (st >> 1) & 7;
}

static uint8_t sensor_diag[9];

/* 0 成功；否则 {错误码<<8 | 命令序号} */
static uint32_t camera_init(void)
{
    ctrl_write(ctrl & ~CTRL_CAM_EN);
    delay_ms(10);
    ctrl_write(ctrl | CTRL_CAM_EN);          /* 传感器上电/解除复位 */
    delay_ms(100);
    for (uint32_t i = 0; i < SC_SEQ_LEN; i++) {
        uint32_t w = sc_seq[i], op = w >> 24, reg = (w >> 8) & 0xFFFF, val = w & 0xFF;
        if (op == 2) {
            if (reg >= 1000) osd_message("SENSOR STREAM ON - SETTLING");
            delay_ms(reg);
            continue;
        }
        int diag = op == 3 && i >= SC_DIAG_FIRST_INDEX;
        if (op == 3 && !diag) return (4u << 8) | i;
        uint8_t rd = 0;
        int r = i2c_xfer(reg, val, op == 1 || diag, &rd);
        if (r != 1) return ((uint32_t)r << 8) | i;
        if (op == 1 && rd != val) return (3u << 8) | i;
        if (diag) sensor_diag[i - SC_DIAG_FIRST_INDEX] = rd;
        delay_ms(1);                          /* STOP-START 间隔 */
    }
    return 0;
}

/* Read-only: verify the live sensor settings without changing the image. */
static void print_camera_registers(void)
{
    static const uint16_t regs[] = {0x3e00,0x3e01,0x3e02,0x320e,0x320f,
                                  0x3e08,0x3e09,0x3e06,0x3e07,0x3221,0x4501,0x0100};
    bsp_printf("camera readback ID=%x:", SC_ID);
    for (uint32_t i=0; i<sizeof(regs)/sizeof(regs[0]); i++) {
        uint8_t value=0;
        int result=i2c_xfer(regs[i],0,1,&value);
        if (result!=1) { bsp_printf(" I2C error %d at %x\r\n",result,regs[i]); return; }
        bsp_printf(" %x=%x",regs[i],value);
    }
    bsp_printf("\r\n");
}

/* AE-only: software reuses the existing APB I2C engine. RGB gains stay unity.
 * No VTS changes: exposure is capped to the existing sensor frame period. */
static uint32_t ae_last,ae_seen,ae_mean,ae_errors;
static unsigned ae_exp=1120,ae_gain=81,ae_max=2988,ae_dirty;
static unsigned ae_gain_reg(unsigned index)
{
    if(index<17) return 0x0020+index;
    if(index<49) return 0x8020+index-17;
    if(index<81) return 0x8120+index-49;
    if(index<113) return 0x8320+index-81;
    return 0x8720;
}
static void ae_init(void)
{
    unsigned vts=((unsigned)sensor_diag[3]<<8)|sensor_diag[4];
    ae_exp=((unsigned)(sensor_diag[0]&15)<<12)|((unsigned)sensor_diag[1]<<4)|(sensor_diag[2]>>4);
    if(vts>=16) ae_max=2*vts-12;
    unsigned gain=((unsigned)sensor_diag[5]<<8)|sensor_diag[6];
    for(ae_gain=0;ae_gain<113&&ae_gain_reg(ae_gain)!=gain;ae_gain++);
    ae_last=now();ae_seen=SC_AE_SEQUENCE;
}
static void ae_poll(void)
{
    uint32_t seq=SC_AE_SEQUENCE,sum=SC_AE_SUM,counts=SC_AE_COUNTS;
    if(seq!=SC_AE_SEQUENCE||seq==ae_seen) return;
    ae_seen=seq;
    if(!streaming||us_since(ae_last)<200000) return;
    unsigned count=counts>>16,clip=counts&65535;
    if(!count) return;
    ae_mean=sum/count;
    unsigned exposure=ae_exp,gain=ae_gain;
    if(exposure>ae_max) exposure=ae_max;
    else if(sum>count*72||clip>(count>>5)) {
        if(gain) gain=gain>8?gain-8:0;
        else {
            unsigned step=(clip>(count>>5)||sum>count*128)?exposure>>1:exposure>>3;
            if(step<4) step=4;
            exposure=exposure>step+4?exposure-step:4;
        }
    } else if(sum<count*56) {
        if(exposure<ae_max) {
            unsigned step=sum<count*28?exposure>>1:exposure>>3;
            if(step<4) step=4;
            exposure+=step;
            if(exposure>ae_max) exposure=ae_max;
        } else gain=gain<109?gain+4:113;
    }
    ae_last=now();
    if(exposure==ae_exp&&gain==ae_gain&&!ae_dirty) return;
    unsigned analog=ae_gain_reg(gain);
    const uint16_t regs[]={0x3812,0x3e00,0x3e01,0x3e02,0x3e08,0x3e09,0x3812};
    const uint8_t values[]={0,exposure>>12,exposure>>4,exposure<<4,analog>>8,analog,0x30};
    unsigned ok=1;
    for(unsigned i=0;i<7;i++) {
        unsigned retry;
        for(retry=0;retry<3;retry++) {
            poll_key3();poll_scan();
            if(i2c_xfer(regs[i],values[i],0,0)==1) break;
        }
        if(retry==3) {ok=0;break;}
    }
    if(ok) {ae_exp=exposure;ae_gain=gain;ae_dirty=0;}
    else {
        ae_errors++;ae_dirty=1;
        /* Always attempt to release a partially written sensor group. */
        for(unsigned i=0;i<3;i++) if(i2c_xfer(0x3812,0x30,0,0)==1) break;
    }
    ae_last=now();
}

/* ---------------- 权重部署：SPI Flash -> 加速器 ---------------- */
/* STN2 complete package: validation then disabled write then commit. */
static int package_byte(void *ctx) { (void)ctx;return spi_read(FLASH_SPI); }
static int package_write(void *ctx,uint32_t a,uint32_t lo,uint32_t hi) {
    (void)ctx;SC_CFG_ADDR=a;SC_CFG_LO=lo;SC_CFG_HI=hi;
    return (SC_STATUS&ST_CFG_REJECT)?-1:0;
}
static void package_control(uint32_t addr) {
    SC_CFG_ADDR=(31u<<16)|addr;SC_CFG_LO=C48_PROFILE;SC_CFG_HI=0;
    bsp_uDelay(10); /* Drain CDC and coefficient half-word write. */
}
static int weights_pass(int load,const c48_package_info *validated,c48_package_info *out) {
    uint32_t a=BLOB_FLASH_ADDR;
    spiFlash_select(FLASH_SPI,0);spi_write(FLASH_SPI,0x03);
    spi_write(FLASH_SPI,(a>>16)&255);spi_write(FLASH_SPI,(a>>8)&255);spi_write(FLASH_SPI,a&255);
    int r=c48_package_pass(0,package_byte,load?package_write:0,validated,out);
    spiFlash_diselect(FLASH_SPI,0);return r;
}
static int weights_load(int mode,uint32_t *us) {
    (void)mode;uint32_t t0=now();c48_package_info checked;
    int r=-6;
    if(SC_ID==0x53430c48u && SC_PROFILE==C48_PROFILE) {
        r=weights_pass(0,0,&checked);
        if(r>0) {
            package_control(0);
            if(ST_STYLES_READY(SC_STATUS)!=0 || (SC_STATUS&ST_CFG_REJECT))r=-7;
            else r=weights_pass(1,&checked,&loaded_package);
            if(r>0) {
                package_control(1);
                if(ST_STYLES_READY(SC_STATUS)!=7 || (SC_STATUS&ST_CFG_REJECT))r=-8;
            }
        }
    }
    *us=us_since(t0);return r;
}

/* 暂停逐帧调度并等调度器回到空闲（加速器空闲时才接受权重写入） */
static int pause_stream(void)
{
    csr_clear(mstatus, MSTATUS_MIE);
    streaming = 0;
    csr_set(mstatus, MSTATUS_MIE);
    uint32_t t0 = now(), idle_since = now();
    while (us_since(idle_since) < 120000) {
        uint32_t st = SC_STATUS;
        if (((st >> 16) & 7) != 0 || !(st & ST_ENGINE_IDLE)) idle_since = now();
        if (us_since(t0) > 1000000) return 0;
    }
    return 1;
}

static void resume_stream(void)
{
    csr_clear(mstatus, MSTATUS_MIE);
    streaming = 1;
    step_frame();
    csr_set(mstatus, MSTATUS_MIE);
}

/* ---------------- 控制台 ---------------- */
static void print_x10(uint32_t v) { bsp_printf("%d.%d", v / 10, v % 10); }

static void print_status(uint32_t t_ms)
{
    /* UART is blocking at 115200 baud. Service the release/scan events between
     * short chunks, instead of deferring them until the whole report is sent. */
    poll_key3(); poll_scan();
    uint32_t st = SC_STATUS;
    bsp_printf("[%d ms] fps=%d.%d%d", t_ms, fps_x100 / 100, fps_x100 / 10 % 10, fps_x100 % 10);
    bsp_printf(" cam="); print_x10(cam_fps_x10);
    bsp_printf(" nn_ms="); print_x10(nn_ms_x10);
    bsp_printf(" nn_max_ms="); print_x10(job_max / 15000);
    poll_key3(); poll_scan();
    bsp_printf(" style=%d view=%d ready=%d proc=%d cap=%d skip=%d run_skip=%d",
               cur_style(), cur_view(), ST_STYLES_READY(st), SC_PROCESSED, SC_CAPTURED,
               SC_SKIPPED, SC_SKIPPED-stream_skip_base);
    poll_key3(); poll_scan();
    bsp_printf(" caperr=%d vid_err=%d uf=%d hdmi_err=%d irq_err=%d",
               SC_CAP_ERRORS, SC_VIDEO_ERRORS, SC_HDMI_UNDERFLOW, SC_HDMI_ERRORS, error_count);
    poll_key3(); poll_scan();
    bsp_printf(" k3=%d k0=%d sw_us=%d sw_max_us=%d\r\n",key3_count, key0_count,
               switch_us_last, switch_us_max);
    poll_key3(); poll_scan();
    bsp_printf("perf first_us=%d input_wait_us=%d output_wait_us=%d",
               first_cycles/150u, input_stall_cycles/150u, output_stall_cycles/150u);
    poll_key3(); poll_scan();
    bsp_printf(" publish_wait_us=%d scan_seq=%d scan_sw_us=%d scan_sw_max_us=%d\r\n",
               SC_PUBLISH_WAIT/100u, SC_SCAN_SEQUENCE, scan_us_last, scan_us_max);
    bsp_printf("AE mean=%d exp_halfline=%d gain_idx=%d i2c_errors=%d AWB=OFF\r\n",ae_mean,ae_exp,ae_gain,ae_errors);
    poll_key3(); poll_scan();
}

/* RGB percentages are converted to Q8.8; all three channels commit at one
 * sensor frame boundary. This path does not change sensor exposure/gain. */
static void print_rgb_gains(void)
{
    uint32_t r=SC_RGB_R, g=SC_RGB_G, b=SC_RGB_B;
    bsp_printf("RGB ID=%x R=",SC_ID); print_x10((sc_rgb_effective(r)*1000u+128)/256);
    bsp_printf("%c G=",'%'); print_x10((sc_rgb_effective(g)*1000u+128)/256);
    bsp_printf("%c B=",'%'); print_x10((sc_rgb_effective(b)*1000u+128)/256);
    bsp_printf("%c Q8.8=%d %d %d pending=%d\r\n",'%',r,g,b,SC_RGB_COMMIT&1);
}

static int rgb_wait(void)
{
    uint32_t t0=now();
    while(SC_RGB_COMMIT&1) if(us_since(t0)>250000) return 0;
    return 1;
}

static void rgb_set(uint32_t r,uint32_t g,uint32_t b)
{
    if(!rgb_wait()) { bsp_printf("RGB request still pending\r\n"); return; }
    SC_RGB_R=r; SC_RGB_G=g; SC_RGB_B=b; SC_RGB_COMMIT=1;
    if(!rgb_wait()) bsp_printf("RGB awaiting camera frame\r\n");
    osd_dirty=1;
    print_rgb_gains();
}

static void rgb_help(void)
{
    bsp_printf("g RGB percent; q RGB Q8.8; g? query; G reset\r\n");
}

static uint32_t rgb_raw;

static void rgb_command(char *p)
{
    uint32_t percent[3];
    uint32_t limit=rgb_raw?65535u:25599u;
    while(*p==' '||*p=='\t') p++;
    if(!*p||*p=='?') {
        if(*p=='?') p++;
        while(*p==' '||*p=='\t') p++;
        if(!*p) { print_rgb_gains(); return; }
        rgb_help(); return;
    }
    for(int i=0;i<3;i++) {
        while(*p==' '||*p=='\t') p++;
        if(*p<'0'||*p>'9') { rgb_help(); return; }
        uint32_t v=0;
        while(*p>='0'&&*p<='9') {
            v=v*10+(*p++-'0');
            if(v>limit) { rgb_help(); return; }
        }
        if(*p&&*p!=' '&&*p!='\t') { rgb_help(); return; }
        percent[i]=v;
    }
    while(*p==' '||*p=='\t') p++;
    if(*p) { rgb_help(); return; }
    if(rgb_raw) rgb_set(percent[0],percent[1],percent[2]);
    else rgb_set((percent[0]*256+50)/100,(percent[1]*256+50)/100,(percent[2]*256+50)/100);
}

static char rgb_line[24];
static uint32_t rgb_active, rgb_len, rgb_bad, rgb_last;
static int rgb_input(char c)
{
    if(!rgb_active) {
        if(c!='g'&&c!='q') return 0;
        rgb_raw=(c=='q');
        rgb_active=1; rgb_len=0; rgb_bad=0; rgb_last=now(); return 1;
    }
    rgb_last=now();
    if(c=='\r'||c=='\n') {
        rgb_line[rgb_len]=0;
        if(rgb_bad) rgb_help(); else rgb_command(rgb_line);
        rgb_active=0;
    } else if(c=='\b'||c==127) {
        if(rgb_len) rgb_len--;
    } else if(rgb_len<sizeof(rgb_line)-1) rgb_line[rgb_len++]=c;
    else rgb_bad=1;
    return 1;
}


/* ---------------- 语音关键词模式（可选，编译期开关，默认关闭） ----------------
 * 推荐做法（见 FPGAProjects/StyleCam_camera/wifi_stream/README.md 第 5 节）：
 * 语音模块 -> ESP32-S3 -> 映射成单字符 0/1/2/v -> 转发到 FPGA uart_rx，
 * 走下面的单字符命令即可，**不需要**打开本开关；默认构建与已验收固件完全一致。
 *
 * 只有把离线语音模块**直连** FPGA uart_rx 时才需要打开：
 *   make / build_fw.py 加 -DSTYLECAM_VOICE_TOKENS=1
 * 打开后串口 't' 进入关键词模式，接受 next / style0..2 / layout / report / reload 等单词；
 * 该模式下单字符命令被忽略（避免单词里的数字/字母误触发），'raw' 切回单字符模式。
 * 开销约 +1.1 KB ROM、+1.1 KB RAM（16 KB 片上 RAM 上从 86% 升到 93%）。 */
#ifndef STYLECAM_VOICE_TOKENS
#define STYLECAM_VOICE_TOKENS 0
#endif

#if STYLECAM_VOICE_TOKENS
static int token_mode;
static char vtok[20];
static int vtok_n;

static int sc_streq(const char *a, const char *b)
{
    while (*a && *a == *b) { a++; b++; }
    return *a == *b;
}

static void act_set_style(uint32_t s)
{
    csr_clear(mstatus, MSTATUS_MIE);
    if (s != cur_style()) {
        ctrl_write((ctrl & ~CTRL_STYLE(3)) | CTRL_STYLE(s));
        mark_switch(s);
    }
    osd_dirty = 1;
    csr_set(mstatus, MSTATUS_MIE);
}

static void act_cycle_view(void)
{
    csr_clear(mstatus, MSTATUS_MIE);
    uint32_t v = cur_view() == 2 ? 0 : cur_view() + 1;
    ctrl_write((ctrl & ~CTRL_VIEW(3)) | CTRL_VIEW(v));
    osd_dirty = 1;
    csr_set(mstatus, MSTATUS_MIE);
}

static void act_reload(void)                             /* 运行中重新从 Flash 装载权重 */
{
    uint32_t us = 0;
    int ok = pause_stream();
    int r = ok ? weights_load(2, &us) : -4;
    bsp_printf("weights reload: %d records, %d us\r\n", r, us);
    if(r>0)resume_stream();else osd_message("WEIGHT LOAD FAILED - PAUSED");
}

static void vocab_dispatch(const char *w)
{
    if (sc_streq(w, "next"))            { act_set_style(cur_style() == 2 ? 0 : cur_style() + 1);
                                          bsp_printf("voice: next -> style %d\r\n", cur_style()); }
    else if (sc_streq(w, "style0") || sc_streq(w, "fauve"))  { act_set_style(0); bsp_printf("voice: style 0\r\n"); }
    else if (sc_streq(w, "style1") || sc_streq(w, "gogh")) { act_set_style(1); bsp_printf("voice: style 1\r\n"); }
    else if (sc_streq(w, "style2") || sc_streq(w, "pencil"))   { act_set_style(2); bsp_printf("voice: style 2\r\n"); }
    else if (sc_streq(w, "layout"))     { act_cycle_view(); bsp_printf("voice: view %d\r\n", cur_view()); }
    else if (sc_streq(w, "report"))     { print_status(0); }
    else if (sc_streq(w, "reload"))     { act_reload(); }
    else if (sc_streq(w, "raw"))        { token_mode = 0; bsp_printf("single-char mode\r\n"); }
    else                                 bsp_printf("voice: unknown word '%s'\r\n", w);
}

/* 返回 1 表示该字符已在关键词模式下被消费 */
static int token_input(char c)
{
    if (!token_mode) return 0;
    if (c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == ',' || c == '.') {
        if (vtok_n) {
            vtok[vtok_n] = 0;
            vocab_dispatch(vtok);
            vtok_n = 0;
        }
    } else if (c >= 'A' && c <= 'Z') {
        if (vtok_n < (int)sizeof(vtok) - 1) vtok[vtok_n++] = (char)(c + 32); else vtok_n = 0;
    } else if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) {
        if (vtok_n < (int)sizeof(vtok) - 1) vtok[vtok_n++] = c; else vtok_n = 0;
    } else {
        vtok_n = 0;                                      /* 非词字符：丢弃当前词 */
    }
    return 1;
}
#endif

static void console(void)
{
    if(rgb_active&&us_since(rgb_last)>2000000) {
        rgb_active=0; bsp_printf("RGB input timed out\r\n");
    }
    while (uart_readOccupancy(BSP_UART_TERMINAL)) {
        char c = uart_read(BSP_UART_TERMINAL);
#if STYLECAM_VOICE_TOKENS
        if(token_input(c)) continue;
#endif
        if(rgb_input(c)) continue;
        if(c=='G') { rgb_set(256,256,256); continue; }
        csr_clear(mstatus, MSTATUS_MIE);
        if (c >= '0' && c <= '2') {
            uint32_t s = c - '0';
            if (s != cur_style()) {
                ctrl_write((ctrl & ~CTRL_STYLE(3)) | CTRL_STYLE(s));
                mark_switch(s);
            }
            osd_dirty = 1;
        } else if (c == 'v') {
            uint32_t v = cur_view() == 2 ? 0 : cur_view() + 1;
            ctrl_write((ctrl & ~CTRL_VIEW(3)) | CTRL_VIEW(v));
            osd_dirty = 1;
        }
        csr_set(mstatus, MSTATUS_MIE);
        if (c == 's') print_status(0);
        if (c == 'c') print_camera_registers();
#if STYLECAM_VOICE_TOKENS
        if (c == 't') { token_mode = 1; vtok_n = 0;
                        bsp_printf("token mode on (voice keywords: next style0 style1 style2 layout report reload raw)\r\n"); }
#endif
        if (c == 'w') {                                  /* 运行中重新从 Flash 装载权重 */
            uint32_t us = 0;
            int ok = pause_stream();
            int r = ok ? weights_load(2, &us) : -4;
            bsp_printf("weights reload: %d records, %d us\r\n", r, us);
            if(r>0)resume_stream();else osd_message("WEIGHT LOAD FAILED - PAUSED");
        }
        if (c == 'h' || c == '?') bsp_printf("0/1/2 style; v view; s status; c sensor; w reload; g/q RGB; G reset"
#if STYLECAM_VOICE_TOKENS
                   ", t voice keywords"
#endif
                   "\r\n");
    }
}

/* 等待一帧发布（轮询计数），超时返回 0 */
static int wait_frame(uint32_t before, uint32_t timeout_ms)
{
    uint32_t t0 = now();
    while (frames == before)
        if (us_since(t0) > timeout_ms * 1000) return 0;
    return 1;
}

void main()
{
    bsp_init();
    bsp_printf("\r\nC48 SC431HAI HDMI ID=%x\r\n", SC_ID);
    ctrl_write(CTRL_STYLE(0) | CTRL_VIEW(0));
    osd_clear_all();
    osd_draw();
    osd_message("WAIT DDR");
    uint32_t t0 = now();
    while (!(SC_STATUS & ST_DDR_READY))
        if (us_since(t0) > 2000000) { bsp_printf("DDR calibration timeout\r\n"); osd_message("DDR CALIBRATION FAILED"); while (1); }
    irq_init();

    /* 权重部署：位流里不含网络权重，由 CPU 从配置 Flash 读出写入 */
    osd_message("LOADING C48 WEIGHTS");
    spiFlash_init(FLASH_SPI, 0);
    /* Active configuration leaves Flash in deep power-down (spi_low_power_mode=on). */
    spiFlash_wake(FLASH_SPI, 0);
    bsp_printf("SPI ID=%x\r\n", spiFlash_manufacturer_id(FLASH_SPI, 0));
    uint32_t wus;
    int wr = weights_load(1, &wus);
    if (wr < 0) {
        bsp_printf("blob error %d at %x\r\n", wr, BLOB_FLASH_ADDR);
        osd_message(wr == -1 ? "BAD BLOB HEADER" : wr == -2 ? "WEIGHT BLOB CRC ERROR" : "WEIGHT LOAD REJECTED");
        while (1);
    }
    bsp_printf("blob@%x n=%d bytes=%d crc=%x us=%d\r\n", BLOB_FLASH_ADDR, wr, loaded_package.word[3],
               loaded_package.word[8], wus);

    osd_message("CONFIGURE SC431HAI");
    uint32_t err = camera_init();
    if (err) {
        char line[40], *p = cat(line, "CAMERA INIT ERROR ");
        p = fmt_u(p, err >> 8); p = cat(p, " AT STEP "); fmt_u(p, err & 0xFF);
        osd_message(line);
        bsp_printf("SC431HAI init failed: code %d at step %d\r\n", err >> 8, err & 0xFF);
        while (1);
    }
    bsp_printf("sensor ready\r\n");
    print_camera_registers();
    print_rgb_gains();

    /* 风格部署：三种风格各跑一次单遍预热 */
    for (uint32_t s = 0; s < 3; s++) {
        char line[48], *p = cat(line, "DEPLOYING STYLE ");
        p = cat(p, STYLE_NAME[s]); cat(p, " (WARMUP)");
        osd_message(line);
        ctrl_write((ctrl & ~CTRL_STYLE(3)) | CTRL_STYLE(s));
        uint32_t before = frames;
        step_frame();
        if (!wait_frame(before, 5000)) {
            bsp_printf("style %d warmup timeout, status %x\r\n", s, SC_STATUS);
            osd_message("STYLE WARMUP TIMEOUT");
            while (1);
        }
        bsp_printf("style %d ready\r\n", s);
    }

    /* 实时运行：每帧由发布中断启动下一帧 */
    ctrl_write((ctrl & ~CTRL_STYLE(3)) | CTRL_STYLE(0));
    stream_skip_base = SC_SKIPPED; /* Keep total skip visible; report warm-up separately. */
    csr_clear(mstatus, MSTATUS_MIE);
    streaming = 1;
    step_frame();
    csr_set(mstatus, MSTATUS_MIE);
    osd_draw();
    bsp_printf("streaming; 0/1/2 style; v view; s status; c sensor; w reload; g/q RGB; G reset"
#if STYLECAM_VOICE_TOKENS
                   ", t voice keywords"
#endif
                   "\r\n");

    ae_init();
    uint32_t t_last = now(), f_last = frames, p_last = last_pub_t, s_last = SC_SENSOR_FRAMES, uptime_ms = 0, ticks = 0;
    while (1) {
        console();
        ae_poll();
        poll_key3();
        poll_scan();
        if (osd_dirty) { osd_dirty = 0; osd_draw(); }
        uint32_t dt = us_since(t_last);
        if (dt >= 1000000) {
            csr_clear(mstatus, MSTATUS_MIE);
            uint32_t f = frames, p = last_pub_t, s = SC_SENSOR_FRAMES;
            csr_set(mstatus, MSTATUS_MIE);
            /* 帧率 = 发布帧数 / 首末发布时刻之差（按帧间隔计，不受统计窗口量化影响） */
            uint32_t pub_10us = (p - p_last) / (BSP_CLINT_HZ / 100000);
            fps_x100 = (f != f_last && pub_10us) ? (f - f_last) * 10000000u / pub_10us : 0;
            fps_x10 = (fps_x100 + 5) / 10;                 /* 四舍五入到 0.1 */
            cam_fps_x10 = (s - s_last) * 10000000u / dt;
            nn_ms_x10 = job_cycles / 15000;             /* 150 MHz accelerator cycles -> 0.1 ms */
            f_last = f; p_last = p; s_last = s; t_last = now(); uptime_ms += dt / 1000;
            osd_draw();
            if (++ticks % 2 == 0) print_status(uptime_ms);
        }
    }
}
