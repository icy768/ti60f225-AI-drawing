#ifndef C48_PROFILE_H
#define C48_PROFILE_H
#include <stdint.h>
#define C48_PROFILE 0xa08a6412u
#define C48_HW_VERSION 0x53430C48u
#define C48_MAX_BLOB_BYTES 500000u
#define C48_BLOB_FLASH_ADDR 0x200000u
typedef struct {uint16_t depth,channels;uint8_t lanes,tail_bits,skip;} c48_layer_layout;
static const c48_layer_layout c48_layout[13]={
 {72,16,2,16,0},
 {432,48,4,0,0},
 {108,48,1,0,0},
 {288,48,2,0,1},
 {108,48,1,0,0},
 {288,48,2,0,1},
 {108,48,1,0,0},
 {288,48,2,0,1},
 {108,48,1,0,0},
 {288,48,2,0,1},
 {108,48,1,0,0},
 {96,16,2,0,0},
 {72,12,6,0,0},
};
#endif
