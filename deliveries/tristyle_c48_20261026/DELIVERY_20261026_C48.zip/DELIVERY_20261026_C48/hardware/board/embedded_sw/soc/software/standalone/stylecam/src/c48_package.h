#ifndef C48_PACKAGE_H
#define C48_PACKAGE_H
#include <stdint.h>
#include "c48_profile.h"

/* A reader returns a byte or -1. A writer returns 0 on success.
 * First pass must use writer=NULL. The board integration then disables the
 * accelerator, repeats with the validated header, and commits only on success.
 * An unsuccessful second pass leaves the accelerator disabled. */
typedef int (*c48_read_byte)(void *);
typedef int (*c48_write_record)(void *,uint32_t,uint32_t,uint32_t);
typedef struct {uint32_t word[16];} c48_package_info;

static uint32_t c48_crc_byte(uint32_t c,uint8_t b) {
    unsigned k;c^=b;
    for(k=0;k<8;k++)c=(c>>1)^(0xedb88320u&(0u-(c&1u)));
    return c;
}
static int c48_word(void *ctx,c48_read_byte read,uint32_t *crc,uint32_t *out) {
    unsigned k;uint32_t w=0;int b;
    for(k=0;k<4;k++){b=read(ctx);if(b<0)return -1;w|=(uint32_t)b<<(8*k);*crc=c48_crc_byte(*crc,(uint8_t)b);}
    *out=w;return 0;
}
static int c48_meta_ok(uint32_t lo,uint32_t hi,int skip) {
    unsigned r=lo&31,s=(lo>>5)&31,s2=(lo>>10)&31;
    uint32_t k=(lo>>15)|((hi&1u)<<17);
    return hi<=1 && r<=25 && s2<=s && s-s2<=16 && (skip || !k);
}
/* Errors: -1 truncated/header, -2 CRC, -3 layout/value, -4 output rejected,
 * -5 header differs from the validated pass. Never binds to a training CRC. */
static int c48_package_pass(void *ctx,c48_read_byte read,c48_write_record write,
                           const c48_package_info *validated,c48_package_info *info) {
    uint32_t crc=0xffffffffu,ignored=0xffffffffu,header_crc=0xffffffffu;
    uint32_t n=0,layer,a,lane,i,j,word,lo,hi,expect;
    for(i=0;i<16;i++)if(c48_word(ctx,read,&ignored,&info->word[i]))return -1;
    for(i=0;i<16;i++){
        word=i==9?0:info->word[i];
        for(j=0;j<4;j++)header_crc=c48_crc_byte(header_crc,(uint8_t)(word>>(8*j)));
        if(validated && info->word[i]!=validated->word[i])return -5;
    }
    if((header_crc^0xffffffffu)!=info->word[9])return -2;
    if(info->word[0]!=0x324e5453u || info->word[1]!=2 || info->word[2]!=64 ||
       info->word[3]>C48_MAX_BLOB_BYTES || info->word[3]<64 ||
       info->word[4]>(C48_MAX_BLOB_BYTES-64)/12 || info->word[3]!=64+12*info->word[4] ||
       info->word[5]!=3 || info->word[6]!=13 || info->word[7]!=C48_PROFILE ||
       info->word[10]!=640 || info->word[11]!=480 || info->word[12]!=1 || info->word[15]!=0)return -1;
    for(layer=0;layer<13;layer++){
        const c48_layer_layout *l=&c48_layout[layer];
        for(a=0;a<l->depth;a++)for(lane=0;lane<l->lanes;lane++){
            if(n++>=info->word[4])return -3;
            if(c48_word(ctx,read,&crc,&word)||c48_word(ctx,read,&crc,&lo)||c48_word(ctx,read,&crc,&hi))return -1;
            expect=0x80000000u|(lane<<21)|(layer<<16)|a;
            if(word!=expect || hi || (lane+1u==l->lanes && l->tail_bits && (lo>>l->tail_bits)))return -3;
            if(write && write(ctx,word,lo,hi))return -4;
        }
        for(a=0;a<3u*l->channels;a++){
            if(n++>=info->word[4])return -3;
            if(c48_word(ctx,read,&crc,&word)||c48_word(ctx,read,&crc,&lo)||c48_word(ctx,read,&crc,&hi))return -1;
            if(word!=((layer<<16)|a) || hi>63)return -3;
            if(write && write(ctx,word,lo,hi))return -4;
        }
        for(a=512;a<515;a++){
            if(n++>=info->word[4])return -3;
            if(c48_word(ctx,read,&crc,&word)||c48_word(ctx,read,&crc,&lo)||c48_word(ctx,read,&crc,&hi))return -1;
            if(word!=((layer<<16)|a) || !c48_meta_ok(lo,hi,l->skip))return -3;
            if(write && write(ctx,word,lo,hi))return -4;
        }
    }
    if(n!=info->word[4])return -3;
    if((crc^0xffffffffu)!=info->word[8])return -2;
    return (int)n;
}
#endif
