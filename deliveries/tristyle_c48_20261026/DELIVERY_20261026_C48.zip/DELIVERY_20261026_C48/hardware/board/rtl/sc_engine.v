// C48 affine, one replay per frame. Model data survives per-frame network reset.
module sc_engine #(parameter WIDTH=640,HEIGHT=480,N_STYLES=3,IN_TRACE=0,IN_FILE="")(
 input clk,system_reset,
 input sink_ready,output [23:0] sink_data,output sink_valid,output new_frame,
 input [23:0] replay_data,input replay_valid,output replay_ready,
 output replay_start,input replay_busy,
 input video_start,input [1:0] video_style,input video_mode,
 output video_idle,output reg video_done,video_ok,output [2:0] video_styles_ready,
 input cpu_cfg_we,cpu_cfg_sel,input [4:0] cpu_cfg_lane,cpu_cfg_layer,input [11:0] cpu_cfg_addr,input [37:0] cpu_cfg_data,output reg cpu_cfg_rejects,
 output reg [31:0] run_cycles,first_output_cycles,input_stalls,output_stalls,
 output reg [31:0] auto_cycles,auto_frames,auto_writes,auto_errors,errors);
 localparam [31:0] PROFILE=32'ha08a6412;
 reg [9:0] por=0;always @(posedge clk)if(!(&por))por<=por+1'b1;
 wire rst=!(&por)||system_reset;
 reg [1:0] state;reg [4:0] reset_count,tail;reg active,start_pulse;
 reg [3:0] style;reg [31:0] produced;
 reg loading;reg [38:0] meta_seen;reg [2:0] ready_styles;
 reg cfg_we,cfg_sel;reg [4:0] cfg_lane,cfg_layer;reg [11:0] cfg_addr;reg [37:0] cfg_data;
 wire net_valid,net_ready;wire [23:0] net_data;wire nrst=rst||(reset_count!=0);
 assign video_idle=(state==0)&&!active&&!replay_busy;
 assign video_styles_ready=ready_styles;
 assign sink_data=net_data;assign sink_valid=net_valid&&active&&!nrst;
 assign replay_ready=active&&net_ready&&!nrst;
 assign replay_start=start_pulse;assign new_frame=start_pulse;
 stylenet_top #(.WIDTH(WIDTH),.HEIGHT(HEIGHT)) net(.clk(clk),.rst(nrst),.style(style),
 .cfg_we(cfg_we),.cfg_sel(cfg_sel),.cfg_layer(cfg_layer),.cfg_lane(cfg_lane),.cfg_addr(cfg_addr),.cfg_data(cfg_data),
 .i_data(replay_data),.i_valid(active&&replay_valid&&!nrst),.i_ready(net_ready),
 .o_data(net_data),.o_valid(net_valid),.o_ready(sink_ready&&active&&!nrst),
 .st_sel(5'd31),.st_arm(1'b0),.st_fs(1'b0),.st_fe(1'b0),.st_idx(8'd0),.st_s1(),.st_s2(),.st_done(),.st_busy());
 always @(posedge clk)begin
  video_done<=0;cfg_we<=0;start_pulse<=0;
  if(rst)begin
   state<=0;reset_count<=0;tail<=0;active<=0;style<=0;produced<=0;
   loading<=0;meta_seen<=0;ready_styles<=0;cpu_cfg_rejects<=0;
   cfg_sel<=0;cfg_lane<=0;cfg_layer<=0;cfg_addr<=0;cfg_data<=0;
   run_cycles<=0;first_output_cycles<=0;input_stalls<=0;output_stalls<=0;
   auto_cycles<=0;auto_frames<=0;auto_writes<=0;auto_errors<=0;errors<=0;video_ok<=0;
  end else begin
   if(cpu_cfg_we)begin
    if(!video_idle)cpu_cfg_rejects<=1;
    else if(!cpu_cfg_sel&&cpu_cfg_layer==31&&cpu_cfg_lane==0&&cpu_cfg_data=={6'd0,PROFILE})begin
     if(cpu_cfg_addr==0)begin loading<=1;meta_seen<=0;ready_styles<=0;cpu_cfg_rejects<=0;end
     else if(cpu_cfg_addr==1&&loading&&(&meta_seen)&&!cpu_cfg_rejects)begin loading<=0;ready_styles<=7;end
     else cpu_cfg_rejects<=1;
    end else if(loading&&cpu_cfg_layer<13)begin
     cfg_we<=1;cfg_sel<=cpu_cfg_sel;cfg_layer<=cpu_cfg_layer;cfg_lane<=cpu_cfg_lane;cfg_addr<=cpu_cfg_addr;cfg_data<=cpu_cfg_data;
     if(!cpu_cfg_sel&&cpu_cfg_lane==0&&cpu_cfg_addr>=512&&cpu_cfg_addr<515)
      meta_seen[cpu_cfg_layer*3+cpu_cfg_addr-512]<=1;
    end else cpu_cfg_rejects<=1;
   end
   if(state!=0)auto_cycles<=auto_cycles+1'b1;
   if(active)begin
    run_cycles<=run_cycles+1'b1;
    if(replay_valid&&!net_ready)input_stalls<=input_stalls+1'b1;
    if(net_valid&&!sink_ready)output_stalls<=output_stalls+1'b1;
    if(net_valid&&sink_ready)begin
     if(produced==0)first_output_cycles<=run_cycles+1'b1;
     produced<=produced+1'b1;
     if(produced==WIDTH*HEIGHT-1)begin active<=0;tail<=16;state<=3;end
    end
   end
   case(state)
    0:if(video_start&&!cpu_cfg_we&&video_idle)begin
     if(video_style<3&&ready_styles[video_style]&&!loading)begin
      style<={2'd0,video_style};state<=1;reset_count<=16;produced<=0;
      run_cycles<=0;first_output_cycles<=0;input_stalls<=0;output_stalls<=0;
      auto_cycles<=0;auto_frames<=1;auto_writes<=0;auto_errors<=0;video_ok<=0;
     end else begin video_done<=1;video_ok<=0;errors<=errors+1'b1;end
    end
    1:if(reset_count!=0)reset_count<=reset_count-1'b1;
      else begin active<=1;start_pulse<=1;state<=2;end
    3:if(tail!=0)tail<=tail-1'b1;
      else if(!replay_busy)begin state<=0;video_done<=1;video_ok<=1;end
    default:;
   endcase
  end
 end
endmodule
