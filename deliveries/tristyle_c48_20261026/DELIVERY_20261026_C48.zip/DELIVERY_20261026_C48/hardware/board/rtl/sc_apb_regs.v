// RISC-V (Sapphire) control and status registers on APB3 slave 0, base 0xF8100000.
// 0x0000-0x0FFF registers (see fw/src/stylecam_regs.h), 0x2000-0x3FFF OSD text cells (one char per word).
// One clock domain (core_clk); PREADY is always 1.
module sc_apb_regs #(parameter [31:0] VERSION=32'h5343_0C48,parameter integer I2C_TICK=1000)(
 input clk,rst,
 input [15:0] paddr,input psel,penable,pwrite,input [31:0] pwdata,output [31:0] prdata,output pready,output pslverr,
 output irq,
 output reg run,output reg step,output reg [1:0] style,output reg [1:0] view,output reg cam_enable,
 output reg [15:0] rgb_r_gain,rgb_g_gain,rgb_b_gain,output reg rgb_request,input rgb_ack,
 input [55:0] ae_data,input ae_request,output reg ae_ack,
 input ev_publish,ev_key3,ev_key2,ev_error,
 input [31:0] st_captured,st_processed,st_skipped,st_cap_errors,st_sensor_frames,st_video_errors,
 input [31:0] st_run_cycles,st_auto_cycles,st_auto_frames,st_hdmi_frames,st_hdmi_underflow,st_hdmi_errors,
 input [31:0] st_first_output,st_input_stalls,st_output_stalls,st_clock_cycles,st_scan_sequence,st_scan_timestamp,st_publish_wait,
 input [1:0] st_scan_style,
 input [7:0] st_flags,input [10:0] st_sched,input [1:0] st_keys,
 input scl_in,sda_in,output scl_low,sda_low,
 output reg osd_we,output reg [10:0] osd_addr,output reg [7:0] osd_data,
 output reg cfg_we,output reg cfg_sel,output reg [4:0] cfg_lane,output reg [4:0] cfg_layer,output reg [11:0] cfg_addr,output reg [37:0] cfg_data);
 assign pready=1'b1;assign pslverr=1'b0;
 wire wr=psel&&penable&&pwrite;
 wire reg_sel=paddr[15:12]==4'h0;wire osd_sel=paddr[15:13]==3'b001;
 wire [5:0] ra=paddr[7:2];
 reg [3:0] pend,en;
 reg [15:0] rgb_r_shadow,rgb_g_shadow,rgb_b_shadow;
 (* async_reg="true" *) reg [1:0] rgb_ack_sync;
 wire rgb_busy=rgb_request!=rgb_ack_sync[1];
 always @(posedge clk) begin
  if(rst) rgb_ack_sync<=0;
  else rgb_ack_sync<={rgb_ack_sync[0],rgb_ack};
 end
 assign irq=|(pend&en);
 // Acknowledged bundled snapshot: source holds data until core-domain ACK.
 // Three request stages allow the two data stages to settle before capture.
 (* async_reg="true" *) reg [2:0] ae_req_sync;
 reg [55:0] ae_data1,ae_data2,ae_snapshot;
 reg [15:0] ae_sequence;
 always @(posedge clk)begin
  if(rst)begin
   ae_req_sync<=0;ae_data1<=0;ae_data2<=0;ae_snapshot<=0;ae_sequence<=0;ae_ack<=0;
  end else begin
   ae_req_sync<={ae_req_sync[1:0],ae_request};ae_data1<=ae_data;ae_data2<=ae_data1;
   if(ae_req_sync[2]!=ae_ack)begin
    ae_snapshot<=ae_data2;ae_sequence<=ae_sequence+1'b1;ae_ack<=ae_req_sync[2];
   end
  end
 end
 // camera I2C engine (16-bit register address, 8-bit data, 7-bit device 0x30)
 reg i2c_start,i2c_read,i2c_done;reg [15:0] i2c_addr;reg [7:0] i2c_wdata;
 wire i2c_busy,i2c_fin;wire [2:0] i2c_result;wire [7:0] i2c_rdata;
 i2c_reg16 #(.TICK_CYCLES(I2C_TICK),.TIMEOUT_TICKS(1000)) cam_i2c(.clk(clk),.reset(rst),.scl_in(scl_in),.sda_in(sda_in),
  .start(i2c_start),.read_op(i2c_read),.reg_addr(i2c_addr),.write_data(i2c_wdata),
  .scl_low(scl_low),.sda_low(sda_low),.busy(i2c_busy),.done(i2c_fin),.result(i2c_result),.read_data(i2c_rdata));
 always @(posedge clk)begin
  step<=0;osd_we<=0;cfg_we<=0;i2c_start<=0;
  if(rst)begin
   rgb_r_shadow<=256;rgb_g_shadow<=256;rgb_b_shadow<=256;
   rgb_r_gain<=256;rgb_g_gain<=256;rgb_b_gain<=256;rgb_request<=0;
   run<=0;style<=0;view<=0;cam_enable<=0;pend<=0;en<=0;i2c_read<=0;i2c_addr<=0;i2c_wdata<=0;i2c_done<=0;
   cfg_sel<=0;cfg_lane<=0;cfg_layer<=0;cfg_addr<=0;cfg_data<=0;osd_addr<=0;osd_data<=0;
  end else begin
   if(i2c_fin)i2c_done<=1;
   // events set pending bits; a W1C write clears them (an event in the same cycle wins)
   if(wr&&reg_sel&&ra==6'h03)pend<=pend&~pwdata[3:0];
   if(ev_publish)pend[0]<=1;if(ev_key3)pend[1]<=1;if(ev_key2)pend[2]<=1;if(ev_error)pend[3]<=1;
   if(wr&&osd_sel)begin osd_we<=1;osd_addr<=paddr[12:2];osd_data<=pwdata[7:0];end
   if(wr&&reg_sel)case(ra)
    6'h01:begin run<=pwdata[0];cam_enable<=pwdata[1];step<=pwdata[2];style<=pwdata[5:4];view<=pwdata[9:8];end
    6'h04:en<=pwdata[3:0];
    6'h05:if(!i2c_busy)begin i2c_addr<=pwdata[15:0];i2c_wdata<=pwdata[23:16];i2c_read<=pwdata[24];i2c_start<=1;i2c_done<=0;end
    // 0x50/54/58: shadow 16-bit Q8.8 gains (0..65535), reference zero -> 255; 0x5C: commit on bit 0.
    // Keep the transferred data stable until the camera acknowledges a frame.
    6'h14:rgb_r_shadow<=pwdata>65535?16'hffff:pwdata[15:0];
    6'h15:rgb_g_shadow<=pwdata>65535?16'hffff:pwdata[15:0];
    6'h16:rgb_b_shadow<=pwdata>65535?16'hffff:pwdata[15:0];
    6'h17:if(pwdata[0]&&!rgb_busy)begin
     rgb_r_gain<=rgb_r_shadow;rgb_g_gain<=rgb_g_shadow;rgb_b_gain<=rgb_b_shadow;
     rgb_request<=!rgb_request;
    end
    // weight-blob record word 0: [31] sel (1 weights, 0 IN coefficients) [25:21] lane [20:16] layer [11:0] address
    6'h18:begin cfg_sel<=pwdata[31];cfg_lane<=pwdata[25:21];cfg_layer<=pwdata[20:16];cfg_addr<=pwdata[11:0];end
    6'h19:cfg_data[31:0]<=pwdata;
    6'h1a:begin cfg_data[37:32]<=pwdata[5:0];cfg_we<=1;end
    default:;
   endcase
  end
 end
 // Shared one-hot address decode; all APB aliases and zero holes retained.
 wire s_00=(reg_sel&&ra==6'h00);
 wire s_01=(reg_sel&&ra==6'h01);
 wire s_02=(reg_sel&&ra==6'h02);
 wire s_03=(reg_sel&&ra==6'h03);
 wire s_04=(reg_sel&&ra==6'h04);
 wire s_06=(reg_sel&&ra==6'h06);
 wire s_08=(reg_sel&&ra==6'h08);
 wire s_09=(reg_sel&&ra==6'h09);
 wire s_0a=(reg_sel&&ra==6'h0a);
 wire s_0b=(reg_sel&&ra==6'h0b);
 wire s_0c=(reg_sel&&ra==6'h0c);
 wire s_0d=(reg_sel&&ra==6'h0d);
 wire s_0e=(reg_sel&&ra==6'h0e);
 wire s_0f=(reg_sel&&ra==6'h0f);
 wire s_10=(reg_sel&&ra==6'h10);
 wire s_11=(reg_sel&&ra==6'h11);
 wire s_12=(reg_sel&&ra==6'h12);
 wire s_13=(reg_sel&&ra==6'h13);
 wire s_14=(reg_sel&&ra==6'h14);
 wire s_15=(reg_sel&&ra==6'h15);
 wire s_16=(reg_sel&&ra==6'h16);
 wire s_17=(reg_sel&&ra==6'h17);
 wire s_1b=(reg_sel&&ra==6'h1b);
 wire s_1c=(reg_sel&&ra==6'h1c);
 wire s_1d=(reg_sel&&ra==6'h1d);
 wire s_1e=(reg_sel&&ra==6'h1e);
 wire s_1f=(reg_sel&&ra==6'h1f);
 wire s_20=(reg_sel&&ra==6'h20);
 wire s_21=(reg_sel&&ra==6'h21);
 wire s_22=(reg_sel&&ra==6'h22);
 wire s_23=(reg_sel&&ra==6'h23);
 wire s_24=(reg_sel&&ra==6'h24);
 wire s_25=(reg_sel&&ra==6'h25);
 wire s_26=(reg_sel&&ra==6'h26);
 wire [31:0] q=({32{s_26}}&32'ha08a6412)|({32{s_00}}&(VERSION))|
  ({32{s_01}}&({22'd0,view,2'd0,style,1'b0,1'b0,cam_enable,run}))|
  ({32{s_02}}&({3'd0,st_keys,st_sched,8'd0,st_flags}))|
  ({32{s_03}}&({28'd0,pend}))|
  ({32{s_04}}&({28'd0,en}))|
  ({32{s_06}}&({15'd0,i2c_done,i2c_rdata,4'd0,i2c_result,i2c_busy||i2c_start}))|
  ({32{s_08}}&(st_captured))|
  ({32{s_09}}&(st_processed))|
  ({32{s_0a}}&(st_skipped))|
  ({32{s_0b}}&(st_cap_errors))|
  ({32{s_0c}}&(st_sensor_frames))|
  ({32{s_0d}}&(st_video_errors))|
  ({32{s_0e}}&(st_run_cycles))|
  ({32{s_0f}}&(st_auto_cycles))|
  ({32{s_10}}&(st_auto_frames))|
  ({32{s_11}}&(st_hdmi_frames))|
  ({32{s_12}}&(st_hdmi_underflow))|
  ({32{s_13}}&(st_hdmi_errors))|
  ({32{s_14}}&({16'd0,rgb_r_shadow}))|
  ({32{s_15}}&({16'd0,rgb_g_shadow}))|
  ({32{s_16}}&({16'd0,rgb_b_shadow}))|
  ({32{s_17}}&({31'd0,rgb_busy}))|
  ({32{s_1b}}&(st_first_output))|
  ({32{s_1c}}&(st_input_stalls))|
  ({32{s_1d}}&(st_output_stalls))|
  ({32{s_1e}}&(st_clock_cycles))|
  ({32{s_1f}}&(st_scan_sequence))|
  ({32{s_20}}&(st_scan_timestamp))|
  ({32{s_21}}&(st_publish_wait))|
  ({32{s_22}}&({30'd0,st_scan_style}))|
  ({32{s_23}}&({16'd0,ae_sequence}))|
  ({32{s_24}}&({8'd0,ae_snapshot[55:32]}))|
  ({32{s_25}}&(ae_snapshot[31:0]));
 assign prdata=q;
endmodule
