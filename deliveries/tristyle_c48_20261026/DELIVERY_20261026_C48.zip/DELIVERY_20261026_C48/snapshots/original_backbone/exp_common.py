# Shared pieces for the two "no quality loss" checks: COCO data, VGG16 features, metrics,
# pretrained SaMST / MicroAST teachers. Content = COCO val2017 (first 4500 train, last 100 eval).
import glob, os, random, sys, types
import torch, torch.nn as nn, torch.nn.functional as F
import torchvision
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
COCO = r"D:\fpga\FPGAProjects\StyleCam\data\val2017"
ART = r"D:\ClaudeTest\art_dataset"
DEV = "cuda"
sys.dont_write_bytecode = True
sys.path.insert(0, os.path.join(HERE, "src"))


def cleanup():
    # release Python garbage and the CUDA caching allocator between runs
    import gc
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()


def mem_report(tag=""):
    # RSS of this process + DataLoader workers, free system RAM, CUDA allocated/reserved (GB)
    import psutil
    p = psutil.Process()
    rss = p.memory_info().rss + sum(c.memory_info().rss for c in p.children(recursive=True))
    free = psutil.virtual_memory().available
    cu = (torch.cuda.memory_allocated() / 2 ** 30, torch.cuda.memory_reserved() / 2 ** 30) if torch.cuda.is_available() else (0, 0)
    return f"[mem {tag} rss {rss / 2 ** 30:.2f}G sysfree {free / 2 ** 30:.2f}G cuda {cu[0]:.2f}/{cu[1]:.2f}G]"


def coco_files():
    f = sorted(glob.glob(os.path.join(COCO, "*.jpg")))
    return f[:4500], f[-100:]


class CropSet(torch.utils.data.Dataset):
    def __init__(self, files, size=256):
        self.files, self.tf = files, torchvision.transforms.Compose([
            torchvision.transforms.RandomResizedCrop(size, scale=(0.3, 1.0)),
            torchvision.transforms.RandomHorizontalFlip(), torchvision.transforms.ToTensor()])

    def __len__(self):
        return len(self.files)

    def __getitem__(self, i):
        return self.tf(Image.open(self.files[i]).convert("RGB"))


def loader(files, bs=8):
    return torch.utils.data.DataLoader(CropSet(files), bs, shuffle=True, num_workers=2, drop_last=True,
                                       persistent_workers=True)


def eval_images(files, size=512):
    tf = torchvision.transforms.Compose([torchvision.transforms.Resize(size), torchvision.transforms.CenterCrop(size),
                                         torchvision.transforms.ToTensor()])
    return torch.stack([tf(Image.open(f).convert("RGB")) for f in files])


class VGG(nn.Module):
    # relu1_2, relu2_2, relu3_3, relu4_3 of ImageNet VGG16
    def __init__(self):
        super().__init__()
        f = torchvision.models.vgg16(weights="IMAGENET1K_V1").features.eval()
        self.s = nn.ModuleList([f[:4], f[4:9], f[9:16], f[16:23]])
        self.register_buffer("m", torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1))
        self.register_buffer("sd", torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1))
        for p in self.parameters():
            p.requires_grad_(False)

    def forward(self, x):
        x, out = (x - self.m) / self.sd, []
        for s in self.s:
            x = s(x)
            out.append(x)
        return out


def gram(f):
    b, c, h, w = f.shape
    f = f.reshape(b, c, h * w)
    return f @ f.transpose(1, 2) / (c * h * w)


def perc(fa, fb):
    return sum((a - b).abs().mean() for a, b in zip(fa, fb))


def highpass(x):
    k = torch.ones(3, 1, 5, 5, device=x.device) / 25
    return x - F.conv2d(F.pad(x, (2, 2, 2, 2), mode="reflect"), k, groups=3)


@torch.no_grad()
def metrics(vgg, out, tgt):
    # per-image means: PSNR, perceptual distance, relative Gram distance, high-frequency energy ratio
    out = out.clamp(0, 1)
    mse = ((out - tgt) ** 2).flatten(1).mean(1)
    fo, ft = vgg(out), vgg(tgt)
    g = sum(((gram(a) - gram(b)).flatten(1).norm(dim=1) / gram(b).flatten(1).norm(dim=1)) for a, b in zip(fo, ft)) / 4
    pd = torch.stack([sum((a[i] - b[i]).abs().mean() for a, b in zip(fo, ft)) for i in range(out.shape[0])])
    hf = highpass(out).pow(2).flatten(1).mean(1) / highpass(tgt).pow(2).flatten(1).mean(1)
    return dict(psnr=(10 * torch.log10(1 / mse)).tolist(), pd=pd.tolist(), gram=g.tolist(), hf=hf.tolist())

def load_samst():
    # official TransformerNet, 10-style checkpoint; style code noise disabled for deterministic eval
    import samst_transfer_net as S
    S.style_representation.forward = lambda self: self.params
    net = S.TransformerNet(style_num=10)
    net.load_state_dict(torch.load(os.path.join(HERE, "ckpt", "samst_epoch_20.model"), map_location="cpu"))
    return net.to(DEV).eval()


def samst_run(net, x, sid):
    # official I/O: input in [0,255], output in [0,255]
    return net(x * 255, style_id=[sid] * x.shape[0])[0] / 255


MICRO_STYLES = ["starry_night.jpg", "wheat-field-with-cypresses-1889.jpg", "almond_blossom.jpg"]


def load_microast():
    import function
    sys.modules["function"] = function
    import microast_net as M
    ck = lambda n: torch.load(os.path.join(HERE, "ckpt", f"microast_{n}.pth.tar"), map_location="cpu")
    ce, se, mo, de = M.Encoder(), M.Encoder(), M.Modulator(), M.Decoder()
    for m, n in [(ce, "content_encoder"), (se, "style_encoder"), (mo, "modulator"), (de, "decoder")]:
        m.load_state_dict(ck(n))
        m.to(DEV).eval()
    tf = torchvision.transforms.Compose([torchvision.transforms.Resize(512), torchvision.transforms.ToTensor()])
    styles = []
    with torch.no_grad():
        for f in MICRO_STYLES:
            s = tf(Image.open(os.path.join(ART, "vangogh", f)).convert("RGB"))[None].to(DEV)
            sf = se(s)
            w, b = mo(sf)
            styles.append((sf, w, b))
    return ce, de, styles


def microast_run(ce, de, style, x):
    sf, w, b = style
    n = x.shape[0]
    # AdaIN only uses style statistics, so a per-channel mean/std map broadcast to batch n is exact
    sf_n = [s.expand(n, -1, -1, -1) for s in sf]
    return de(ce(x), sf_n, [t.expand(n, -1, -1, -1) for t in w], [t.expand(n, -1, -1, -1) for t in b], 1.0)
