# Exp2: does a slimmer multi-style net keep quality, and which per-style mechanism holds up?
# Teacher = pretrained SaMST, styles 5/7/9 (most mutually distinct of its 10). Students = deployed
# v21b skeleton (TinyStyleNet C=24 Fc=16 n_res=4 dw1) with one per-style mechanism, at C=24 and C=48.
# Same data, loss, steps for all. Metrics vs teacher + style-separation retention, 100 COCO @512.
import json, os, sys, time
import torch, torch.nn as nn, torch.nn.functional as F
import exp_common as E

STEPS = int(os.environ.get("EXP2_STEPS", 6000))
LR, W_PERC, S, CLIP = float(os.environ.get("EXP2_LR", 5e-4)), 0.1, 3, 1.0
MECHS = os.environ.get("EXP2_MECHS", "cin,microast,samst,msg,bank").split(",")
WIDTHS = [int(c) for c in os.environ.get("EXP2_WIDTHS", "24,48").split(",")]
T_STYLES = [5, 7, 9]


class SNorm(nn.Module):
    # IN (frame statistics) + per-style gamma/beta, as in v21b CondNorm.
    # use_in=False: per-style affine only (no frame statistics) -> foldable into requant scale/bias
    def __init__(self, c, use_in=True):
        super().__init__()
        self.use_in = use_in
        self.g, self.b = nn.Parameter(torch.ones(S, c)), nn.Parameter(torch.zeros(S, c))

    def forward(self, x, sid):
        x = F.instance_norm(x) if self.use_in else x
        return x * self.g[sid].view(1, -1, 1, 1) + self.b[sid].view(1, -1, 1, 1)


class PConv(nn.Module):
    # conv whose weights are shared (ns=1) or one copy per style (ns=S)
    def __init__(self, cin, cout, k, stride=1, groups=1, ns=1, bias=False, identity=False):
        super().__init__()
        w = torch.empty(cout, cin // groups, k, k)
        nn.init.kaiming_normal_(w, nonlinearity="relu")
        if identity:
            w = torch.eye(cout).view(cout, cin, 1, 1)
        self.w = nn.Parameter(w[None].repeat(ns, 1, 1, 1, 1))
        self.b = nn.Parameter(torch.zeros(cout)) if bias else None
        self.stride, self.groups, self.ns = stride, groups, ns

    def forward(self, x, sid):
        return F.conv2d(x, self.w[sid if self.ns > 1 else 0], self.b, self.stride, self.w.shape[-1] // 2, 1, self.groups)


class Block(nn.Module):
    # v21b dw1 residual block: dw3 - IN - ReLU - pw1 - IN - (+skip) - ReLU
    def __init__(self, c, mech, use_in=True):
        super().__init__()
        self.mech = mech
        self.dw = PConv(c, c, 3, groups=c, ns=S if mech == "samst" else 1)
        self.n1, self.pw, self.n2 = SNorm(c, use_in), PConv(c, c, 1), SNorm(c, use_in)
        if mech == "microast":   # filterMod: w * h + b * x, per style per channel
            self.fw, self.fb = nn.Parameter(torch.ones(S, c)), nn.Parameter(torch.zeros(S, c))
        if mech == "samst":      # SCM: per-style channel scale on the skip
            self.ca = nn.Parameter(torch.ones(S, c))

    def forward(self, x, sid):
        h = self.n1(self.dw(x, sid), sid)
        if self.mech == "microast":
            h = self.fw[sid].view(1, -1, 1, 1) * h + self.fb[sid].view(1, -1, 1, 1) * x
        h = self.n2(self.pw(F.relu(h), sid), sid)
        skip = x * self.ca[sid].view(1, -1, 1, 1) if self.mech == "samst" else x
        return F.relu(skip + h)


class Student(nn.Module):
    # norm="in": IN after every layer (v21b); "affine": per-style affine only, no frame statistics.
    # res="quarter": trunk at 1/4 (v21b); "half": e2 stride 1, trunk at 1/2, no decoder upsample.
    def __init__(self, mech, C=24, Fc=16, n_res=4, norm="in", res="quarter"):
        super().__init__()
        self.mech, self.res = mech, res
        ui = norm == "in"
        self.e1, self.n_e1 = PConv(3, Fc, 3, 2), SNorm(Fc, ui)
        self.e2, self.n_e2 = PConv(Fc, C, 3, 2 if res == "quarter" else 1), SNorm(C, ui)
        if mech == "msg":
            self.mix = PConv(C, C, 1, ns=S, identity=True)
        if mech == "bank":
            self.bank = nn.ModuleList([PConv(C, C, 3, ns=S) for _ in range(2)])
            self.bank_n = nn.ModuleList([SNorm(C, ui) for _ in range(2)])
        self.blocks = nn.ModuleList([Block(C, mech, ui) for _ in range(n_res)])
        self.d1a, self.n_d1a = PConv(C, C, 3, groups=C), SNorm(C, ui)
        self.d1b, self.n_d1b = PConv(C, Fc, 1), SNorm(Fc, ui)
        self.d2 = PConv(Fc, 12, 3, bias=True)

    def forward(self, x, sid):
        x = F.relu(self.n_e1(self.e1(x, sid), sid))
        x = F.relu(self.n_e2(self.e2(x, sid), sid))
        if self.mech == "msg":
            x = self.mix(x, sid)
        if self.mech == "bank":
            for c, n in zip(self.bank, self.bank_n):
                x = F.relu(n(c(x, sid), sid))
        for b in self.blocks:
            x = b(x, sid)
        if self.res == "quarter":
            x = F.interpolate(x, scale_factor=2, mode="nearest")
        x = F.relu(self.n_d1a(self.d1a(x, sid), sid))
        x = F.relu(self.n_d1b(self.d1b(x, sid), sid))
        return F.pixel_shuffle(self.d2(x, sid), 2)

    def param_split(self):
        # (shared, per-style) counts in deploy form
        shared = per = 0
        for n, p in self.named_parameters():
            if p.shape[0] == S and (n.endswith(".w") and p.dim() == 5 or p.dim() == 2):
                per += p[0].numel()
            else:
                shared += p.numel()
        return shared, per

@torch.no_grad()
def student_macs(net, H=480, W=640):
    # conv MACs per frame (GMAC) via hooks on PConv outputs
    tot, hooks = [0], []
    for m in net.modules():
        if isinstance(m, PConv):
            # w: [ns, cout, cin/groups, k, k]; MACs = output elements x (cin/groups) x k x k
            hooks.append(m.register_forward_hook(lambda mod, i, o: tot.__setitem__(
                0, tot[0] + o[0].numel() * mod.w.shape[2] * mod.w.shape[3] * mod.w.shape[4])))
    net(torch.zeros(1, 3, H, W, device=next(net.parameters()).device), 0)
    for h in hooks:
        h.remove()
    return tot[0] / 1e9


@torch.no_grad()
def evaluate(net, teacher, x_ev, vgg):
    per_style, outs_s, outs_t = [], [[] for _ in range(S)], [[] for _ in range(S)]
    for s in range(S):
        m = {"psnr": [], "pd": [], "gram": [], "hf": []}
        for i in range(0, len(x_ev), 4):
            x = x_ev[i:i + 4].to(E.DEV)
            t = E.samst_run(teacher, x, T_STYLES[s]).clamp(0, 1)
            y = net(x, s).clamp(0, 1)
            r = E.metrics(vgg, y, t)
            for k in m:
                m[k] += r[k]
            outs_s[s].append([E.gram(f) for f in vgg(y)[1:]])
            outs_t[s].append([E.gram(f) for f in vgg(t)[1:]])
        per_style.append(m)
    # style separation retention: pairwise Gram distance between styles, student / teacher
    sep = {}
    for a in range(S):
        for b in range(a + 1, S):
            ds = dt = 0.0
            for ba, bb, ta, tb in zip(outs_s[a], outs_s[b], outs_t[a], outs_t[b]):
                ds += sum((u - v).flatten(1).norm(dim=1).sum().item() for u, v in zip(ba, bb))
                dt += sum((u - v).flatten(1).norm(dim=1).sum().item() for u, v in zip(ta, tb))
            sep[f"{a}-{b}"] = ds / dt
    return per_style, sep


AE_STEPS = int(os.environ.get("EXP2_AE_STEPS", 8000))


def pretrain_ae(C, tl, x_ev, tag="", **kw):
    # shared warm start per backbone: reconstruct the input (v21b base recipe: lr 2e-3 OneCycle, clip 1)
    path = os.path.join(E.HERE, "out", f"ae_C{C}{tag}.pt")
    if os.path.exists(path):
        return torch.load(path, map_location=E.DEV)
    torch.manual_seed(0)
    net = Student("cin", C, **kw).to(E.DEV).train()
    opt = torch.optim.Adam(net.parameters(), 2e-3)
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, 2e-3, total_steps=AE_STEPS, pct_start=0.05)
    it, step, t0 = iter(tl), 0, time.time()
    while step < AE_STEPS:
        try:
            x = next(it).to(E.DEV)
        except StopIteration:
            it = iter(tl)
            continue
        loss = (net(x, step % S) - x).abs().mean()
        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(net.parameters(), CLIP)
        opt.step()
        sched.step()
        step += 1
    net.eval()
    with torch.no_grad():
        x = x_ev[:8].to(E.DEV)
        psnr = 10 * torch.log10(1 / ((net(x, 0).clamp(0, 1) - x) ** 2).mean()).item()
    print(f"  AE C{C}{tag}: {AE_STEPS} steps, eval PSNR {psnr:.2f} dB, {time.time() - t0:.0f}s", flush=True)
    torch.save(net.state_dict(), path)
    return net.state_dict()


def warm_start(net, ae):
    # shared weights -> every per-style copy; mechanism-only params keep their identity-like init
    own = net.state_dict()
    for k, v in ae.items():
        if k in own:
            own[k] = v.expand_as(own[k]).clone() if own[k].shape != v.shape else v.clone()
    net.load_state_dict(own)
    if net.mech == "bank":   # 3x3 bank starts as identity (center tap)
        with torch.no_grad():
            for c in net.bank:
                c.w.zero_()
                c.w[:, :, :, 1, 1] = torch.eye(c.w.shape[1])


def train(mech, C, teacher, tl, x_ev, vgg, tag="", **kw):
    torch.manual_seed(0)
    net = Student(mech, C, **kw).to(E.DEV)
    warm_start(net, pretrain_ae(C, tl, x_ev, tag, **kw))
    net.train()
    opt = torch.optim.Adam(net.parameters(), LR)
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, LR, total_steps=STEPS, pct_start=0.05)
    it, t0, step = iter(tl), time.time(), 0
    while step < STEPS:
        try:
            x = next(it).to(E.DEV)
        except StopIteration:
            it = iter(tl)
            continue
        s = step % S
        with torch.no_grad():
            tgt = E.samst_run(teacher, x, T_STYLES[s]).clamp(0, 1)
        y = net(x, s)
        loss = (y - tgt).abs().mean() + W_PERC * E.perc(vgg(y), vgg(tgt))
        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(net.parameters(), CLIP)
        opt.step()
        sched.step()
        step += 1
        if step % (100 if STEPS <= 1000 else 1000) == 0:
            print(f"  {mech} C{C} step {step} loss {loss.item():.4f} {time.time() - t0:.0f}s {E.mem_report()}", flush=True)
    net.eval()
    per_style, sep = evaluate(net, teacher, x_ev, vgg)
    sh, ps = net.param_split()
    torch.save(net.state_dict(), os.path.join(E.HERE, "out", f"exp2_{mech}_C{C}{tag}.pt"))
    macs = student_macs(net)
    del net, opt, sched
    return dict(shared=sh, per_style_params=ps, deploy3=sh + S * ps, per_style=per_style, sep=sep, gmac_640x480=macs,
                seconds=time.time() - t0)


if __name__ == "__main__":
    tr, ev = E.coco_files()
    n_ev = int(os.environ.get("EXP2_NEV", 100))
    x_ev = E.eval_images(ev[:n_ev])
    vgg, teacher, tl = E.VGG().to(E.DEV), E.load_samst(), E.loader(tr)
    path = os.path.join(E.HERE, "out", os.environ.get("EXP2_OUT", "exp2_results.json"))
    res = json.load(open(path)) if os.path.exists(path) else {}
    only = [k for k in os.environ.get("EXP2_KEYS", "").split(",") if k]
    print("start", E.mem_report(), flush=True)
    for C in WIDTHS:
        for mech in MECHS:
            key = f"{mech}_C{C}"
            if key in res or (only and key not in only):
                continue
            r = train(mech, C, teacher, tl, x_ev, vgg)
            res = json.load(open(path)) if os.path.exists(path) else {}
            res[key] = r
            json.dump(res, open(path, "w"))
            mean = lambda k: round(sum(sum(m[k]) / len(m[k]) for m in r["per_style"]) / S, 3)
            print(key, "deploy3", r["deploy3"], "psnr", mean("psnr"), "pd", mean("pd"), "gram", mean("gram"),
                  "hf", mean("hf"), "sep", {k: round(v, 3) for k, v in r["sep"].items()}, flush=True)
            del r
            E.cleanup()
            print("after", key, E.mem_report(), flush=True)
