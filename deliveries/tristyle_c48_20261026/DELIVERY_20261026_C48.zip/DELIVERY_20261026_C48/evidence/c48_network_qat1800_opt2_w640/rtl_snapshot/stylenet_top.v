// Fixed C48 affine quarter backbone. All learned numeric values are loaded via cfg.
module stylenet_top #(parameter WIDTH=640,HEIGHT=480)(
 input clk,rst,input [3:0] style,
 input cfg_we,cfg_sel,input [4:0] cfg_layer,cfg_lane,input [11:0] cfg_addr,input [37:0] cfg_data,
 input [23:0] i_data,input i_valid,output i_ready,output [23:0] o_data,output o_valid,input o_ready,
 input [4:0] st_sel,input st_arm,st_fs,st_fe,input [7:0] st_idx,
 output [39:0] st_s1,output [59:0] st_s2,output st_done,st_busy);
 assign st_s1=0;assign st_s2=0;assign st_done=0;assign st_busy=0;
 wire [31:0] d0,s0;wire v0,r0;
 wire [31:0] d1,s1;wire v1,r1;
 wire [31:0] d2,s2;wire v2,r2;
 wire [31:0] d3,s3;wire v3,r3;
 wire [31:0] d4,s4;wire v4,r4;
 wire [31:0] d5,s5;wire v5,r5;
 wire [31:0] d6,s6;wire v6,r6;
 wire [31:0] d7,s7;wire v7,r7;
 wire [31:0] d8,s8;wire v8,r8;
 wire [31:0] d9,s9;wire v9,r9;
 wire [31:0] d10,s10;wire v10,r10;
 wire [31:0] d11,s11;wire v11,r11;
 wire [31:0] d12,s12;wire v12,r12;
 // 0: e1
 conv_layer #(.K(3),.DW(0),.STRIDE(2),.UP(0),
 .GI(3),.CIN(3),.COUT(16),.G(4),.W(WIDTH/1),.H(HEIGHT/1),
 .PE(2),.CFG_PE(2),.SKIP_ADD(0),.FWD(0),.NSTY(3)) u_l0(
 .clk(clk),.rst(rst),.style(style),.cfg_we(cfg_we&&cfg_layer==0),.cfg_sel(cfg_sel),
 .cfg_lane(cfg_lane),.cfg_addr(cfg_addr),.cfg_data(cfg_data),
 .i_data(i_data),.i_side(24'd0),
 .i_valid(i_valid),.i_ready(i_ready),
 .o_data(d0),.o_side(s0),.o_valid(v0),.o_ready(r0),.st_v(),.st_a(),.st_ch());
 // 1: e2
 conv_layer #(.K(3),.DW(0),.STRIDE(2),.UP(0),
 .GI(4),.CIN(16),.COUT(48),.G(4),.W(WIDTH/2),.H(HEIGHT/2),
 .PE(4),.CFG_PE(4),.SKIP_ADD(0),.FWD(0),.NSTY(3)) u_l1(
 .clk(clk),.rst(rst),.style(style),.cfg_we(cfg_we&&cfg_layer==1),.cfg_sel(cfg_sel),
 .cfg_lane(cfg_lane),.cfg_addr(cfg_addr),.cfg_data(cfg_data),
 .i_data(d0),.i_side(s0),
 .i_valid(v0),.i_ready(r0),
 .o_data(d1),.o_side(s1),.o_valid(v1),.o_ready(r1),.st_v(),.st_a(),.st_ch());
 // 2: blocks.0.dw
 conv_layer #(.K(3),.DW(1),.STRIDE(1),.UP(0),
 .GI(4),.CIN(48),.COUT(48),.G(4),.W(WIDTH/4),.H(HEIGHT/4),
 .PE(1),.CFG_PE(1),.SKIP_ADD(0),.FWD(1),.NSTY(3)) u_l2(
 .clk(clk),.rst(rst),.style(style),.cfg_we(cfg_we&&cfg_layer==2),.cfg_sel(cfg_sel),
 .cfg_lane(cfg_lane),.cfg_addr(cfg_addr),.cfg_data(cfg_data),
 .i_data(d1),.i_side(s1),
 .i_valid(v1),.i_ready(r1),
 .o_data(d2),.o_side(s2),.o_valid(v2),.o_ready(r2),.st_v(),.st_a(),.st_ch());
 // 3: blocks.0.pw
 conv_layer #(.K(1),.DW(0),.STRIDE(1),.UP(0),
 .GI(4),.CIN(48),.COUT(48),.G(4),.W(WIDTH/4),.H(HEIGHT/4),
 .PE(2),.CFG_PE(2),.SKIP_ADD(1),.FWD(0),.NSTY(3)) u_l3(
 .clk(clk),.rst(rst),.style(style),.cfg_we(cfg_we&&cfg_layer==3),.cfg_sel(cfg_sel),
 .cfg_lane(cfg_lane),.cfg_addr(cfg_addr),.cfg_data(cfg_data),
 .i_data(d2),.i_side(s2),
 .i_valid(v2),.i_ready(r2),
 .o_data(d3),.o_side(s3),.o_valid(v3),.o_ready(r3),.st_v(),.st_a(),.st_ch());
 // 4: blocks.1.dw
 conv_layer #(.K(3),.DW(1),.STRIDE(1),.UP(0),
 .GI(4),.CIN(48),.COUT(48),.G(4),.W(WIDTH/4),.H(HEIGHT/4),
 .PE(1),.CFG_PE(1),.SKIP_ADD(0),.FWD(1),.NSTY(3)) u_l4(
 .clk(clk),.rst(rst),.style(style),.cfg_we(cfg_we&&cfg_layer==4),.cfg_sel(cfg_sel),
 .cfg_lane(cfg_lane),.cfg_addr(cfg_addr),.cfg_data(cfg_data),
 .i_data(d3),.i_side(s3),
 .i_valid(v3),.i_ready(r3),
 .o_data(d4),.o_side(s4),.o_valid(v4),.o_ready(r4),.st_v(),.st_a(),.st_ch());
 // 5: blocks.1.pw
 conv_layer #(.K(1),.DW(0),.STRIDE(1),.UP(0),
 .GI(4),.CIN(48),.COUT(48),.G(4),.W(WIDTH/4),.H(HEIGHT/4),
 .PE(2),.CFG_PE(2),.SKIP_ADD(1),.FWD(0),.NSTY(3)) u_l5(
 .clk(clk),.rst(rst),.style(style),.cfg_we(cfg_we&&cfg_layer==5),.cfg_sel(cfg_sel),
 .cfg_lane(cfg_lane),.cfg_addr(cfg_addr),.cfg_data(cfg_data),
 .i_data(d4),.i_side(s4),
 .i_valid(v4),.i_ready(r4),
 .o_data(d5),.o_side(s5),.o_valid(v5),.o_ready(r5),.st_v(),.st_a(),.st_ch());
 // 6: blocks.2.dw
 conv_layer #(.K(3),.DW(1),.STRIDE(1),.UP(0),
 .GI(4),.CIN(48),.COUT(48),.G(4),.W(WIDTH/4),.H(HEIGHT/4),
 .PE(1),.CFG_PE(1),.SKIP_ADD(0),.FWD(1),.NSTY(3)) u_l6(
 .clk(clk),.rst(rst),.style(style),.cfg_we(cfg_we&&cfg_layer==6),.cfg_sel(cfg_sel),
 .cfg_lane(cfg_lane),.cfg_addr(cfg_addr),.cfg_data(cfg_data),
 .i_data(d5),.i_side(s5),
 .i_valid(v5),.i_ready(r5),
 .o_data(d6),.o_side(s6),.o_valid(v6),.o_ready(r6),.st_v(),.st_a(),.st_ch());
 // 7: blocks.2.pw
 conv_layer #(.K(1),.DW(0),.STRIDE(1),.UP(0),
 .GI(4),.CIN(48),.COUT(48),.G(4),.W(WIDTH/4),.H(HEIGHT/4),
 .PE(2),.CFG_PE(2),.SKIP_ADD(1),.FWD(0),.NSTY(3)) u_l7(
 .clk(clk),.rst(rst),.style(style),.cfg_we(cfg_we&&cfg_layer==7),.cfg_sel(cfg_sel),
 .cfg_lane(cfg_lane),.cfg_addr(cfg_addr),.cfg_data(cfg_data),
 .i_data(d6),.i_side(s6),
 .i_valid(v6),.i_ready(r6),
 .o_data(d7),.o_side(s7),.o_valid(v7),.o_ready(r7),.st_v(),.st_a(),.st_ch());
 // 8: blocks.3.dw
 conv_layer #(.K(3),.DW(1),.STRIDE(1),.UP(0),
 .GI(4),.CIN(48),.COUT(48),.G(4),.W(WIDTH/4),.H(HEIGHT/4),
 .PE(1),.CFG_PE(1),.SKIP_ADD(0),.FWD(1),.NSTY(3)) u_l8(
 .clk(clk),.rst(rst),.style(style),.cfg_we(cfg_we&&cfg_layer==8),.cfg_sel(cfg_sel),
 .cfg_lane(cfg_lane),.cfg_addr(cfg_addr),.cfg_data(cfg_data),
 .i_data(d7),.i_side(s7),
 .i_valid(v7),.i_ready(r7),
 .o_data(d8),.o_side(s8),.o_valid(v8),.o_ready(r8),.st_v(),.st_a(),.st_ch());
 // 9: blocks.3.pw
 conv_layer #(.K(1),.DW(0),.STRIDE(1),.UP(0),
 .GI(4),.CIN(48),.COUT(48),.G(4),.W(WIDTH/4),.H(HEIGHT/4),
 .PE(2),.CFG_PE(2),.SKIP_ADD(1),.FWD(0),.NSTY(3)) u_l9(
 .clk(clk),.rst(rst),.style(style),.cfg_we(cfg_we&&cfg_layer==9),.cfg_sel(cfg_sel),
 .cfg_lane(cfg_lane),.cfg_addr(cfg_addr),.cfg_data(cfg_data),
 .i_data(d8),.i_side(s8),
 .i_valid(v8),.i_ready(r8),
 .o_data(d9),.o_side(s9),.o_valid(v9),.o_ready(r9),.st_v(),.st_a(),.st_ch());
 // 10: d1a
 conv_layer #(.K(3),.DW(1),.STRIDE(1),.UP(1),
 .GI(4),.CIN(48),.COUT(48),.G(4),.W(WIDTH/4),.H(HEIGHT/4),
 .PE(1),.CFG_PE(1),.SKIP_ADD(0),.FWD(0),.NSTY(3)) u_l10(
 .clk(clk),.rst(rst),.style(style),.cfg_we(cfg_we&&cfg_layer==10),.cfg_sel(cfg_sel),
 .cfg_lane(cfg_lane),.cfg_addr(cfg_addr),.cfg_data(cfg_data),
 .i_data(d9),.i_side(s9),
 .i_valid(v9),.i_ready(r9),
 .o_data(d10),.o_side(s10),.o_valid(v10),.o_ready(r10),.st_v(),.st_a(),.st_ch());
 // 11: d1b
 conv_layer #(.K(1),.DW(0),.STRIDE(1),.UP(0),
 .GI(4),.CIN(48),.COUT(16),.G(4),.W(WIDTH/2),.H(HEIGHT/2),
 .PE(2),.CFG_PE(2),.SKIP_ADD(0),.FWD(0),.NSTY(3)) u_l11(
 .clk(clk),.rst(rst),.style(style),.cfg_we(cfg_we&&cfg_layer==11),.cfg_sel(cfg_sel),
 .cfg_lane(cfg_lane),.cfg_addr(cfg_addr),.cfg_data(cfg_data),
 .i_data(d10),.i_side(s10),
 .i_valid(v10),.i_ready(r10),
 .o_data(d11),.o_side(s11),.o_valid(v11),.o_ready(r11),.st_v(),.st_a(),.st_ch());
 // 12: d2
 conv_layer #(.K(3),.DW(0),.STRIDE(1),.UP(0),
 .GI(4),.CIN(16),.COUT(12),.G(4),.W(WIDTH/2),.H(HEIGHT/2),
 .PE(6),.CFG_PE(6),.SKIP_ADD(0),.FWD(0),.NSTY(3)) u_l12(
 .clk(clk),.rst(rst),.style(style),.cfg_we(cfg_we&&cfg_layer==12),.cfg_sel(cfg_sel),
 .cfg_lane(cfg_lane),.cfg_addr(cfg_addr),.cfg_data(cfg_data),
 .i_data(d11),.i_side(s11),
 .i_valid(v11),.i_ready(r11),
 .o_data(d12),.o_side(s12),.o_valid(v12),.o_ready(r12),.st_v(),.st_a(),.st_ch());
 pixshuf #(.WL(WIDTH/2),.HL(HEIGHT/2)) u_ps(.clk(clk),.rst(rst),
 .i_data(d12),.i_valid(v12),.i_ready(r12),.o_data(o_data),.o_valid(o_valid),.o_ready(o_ready));
endmodule
