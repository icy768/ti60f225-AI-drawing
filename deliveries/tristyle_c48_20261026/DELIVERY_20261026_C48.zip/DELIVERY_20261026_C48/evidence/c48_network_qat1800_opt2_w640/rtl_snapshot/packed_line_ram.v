// Sequential 32-bit writes; arbitrary synchronous reads, with old-data semantics.
// Four words share a 128-bit RAM row. Forward partially collected writes until
// the fourth word commits the complete row. Frame writers always restart at 0.
module packed_line_ram(
 input clk,we,input [11:0] waddr,input [31:0] wdata,
 input re,input [11:0] raddr,output [31:0] rdata);
 reg [127:0] mem[0:959];
 reg [127:0] stage;
 reg [9:0] pending_addr;
 reg [3:0] pending_mask=0;
 reg [127:0] read_row;
 reg [1:0] read_lane;
 reg read_bypass;
 reg [31:0] read_staged;
 always @(posedge clk) begin
  if(we)begin
   stage[waddr[1:0]*32 +: 32]<=wdata;
   if(waddr[1:0]==0)begin
    pending_addr<=waddr[11:2];
    pending_mask<=pending_addr==waddr[11:2]?(pending_mask|4'b0001):4'b0001;
   end
   else if(waddr[1:0]==3)begin mem[waddr[11:2]]<={wdata,stage[95:0]};pending_mask<=0;end
   else pending_mask[waddr[1:0]]<=1;
  end
  if(re)begin
   read_row<=mem[raddr[11:2]];read_lane<=raddr[1:0];
   read_bypass<=pending_addr==raddr[11:2]&&pending_mask[raddr[1:0]];
   read_staged<=stage[raddr[1:0]*32 +: 32];
  end
 end
 assign rdata=read_bypass?read_staged:read_row[read_lane*32 +: 32];
endmodule
