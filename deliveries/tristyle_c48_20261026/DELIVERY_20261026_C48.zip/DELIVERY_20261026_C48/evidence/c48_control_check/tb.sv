`timescale 1ns/1ps
module stylenet_top #(parameter WIDTH=640,HEIGHT=480)(input clk,rst,input [3:0] style,
input cfg_we,cfg_sel,input [4:0] cfg_layer,cfg_lane,input [11:0] cfg_addr,input [37:0] cfg_data,
input [23:0] i_data,input i_valid,output i_ready,output [23:0] o_data,output o_valid,input o_ready,
input [4:0] st_sel,input st_arm,st_fs,st_fe,input [7:0] st_idx,output [39:0] st_s1,output [59:0] st_s2,output st_done,st_busy);
assign o_data=i_data;assign o_valid=i_valid&&!rst;assign i_ready=o_ready&&!rst;
assign st_s1=0;assign st_s2=0;assign st_done=0;assign st_busy=0;
endmodule
module tb;
reg clk=0,nc=0;always #5 clk=~clk;always #3 nc=~nc;
reg reset=1,start=0,cw=0;reg [1:0] style=0;reg cs=0;reg [4:0] cl=0,cn=0;reg [11:0] ca=0;reg [37:0] cd=0;
wire idle,done,ok,reject;wire [2:0] styles;wire replay_start,new_frame,rr,sv;wire [23:0] sd;
reg [23:0] rd=0;reg rv=0,busy=0,sr=1;integer outputs=0,j,l,s,cycle=0;
sc_engine_cdc #(.WIDTH(8),.HEIGHT(4)) dut(.clk(clk),.system_reset(reset),.nc(nc),.nrst(reset),
.sink_ready(sr),.sink_data(sd),.sink_valid(sv),.new_frame(new_frame),.replay_data(rd),.replay_valid(rv),.replay_ready(rr),.replay_start(replay_start),.replay_busy(busy),
.video_start(start),.video_style(style),.video_mode(1'b0),.video_bank(2'd0),.video_idle(idle),.video_done(done),.video_ok(ok),.video_styles_ready(styles),
.cpu_cfg_we(cw),.cpu_cfg_sel(cs),.cpu_cfg_lane(cn),.cpu_cfg_layer(cl),.cpu_cfg_addr(ca),.cpu_cfg_data(cd),.cpu_cfg_rejects(reject));
always @(negedge nc)begin cycle=cycle+1;sr=cycle%7<5;end
always @(posedge nc)if(sv&&sr)begin if(sd!==outputs)$fatal(1,"DATA");outputs=outputs+1;end
task write(input integer layer,input integer addr,input [37:0] value);
begin wait(idle);@(negedge clk);cl=layer;ca=addr;cd=value;cw=1;@(negedge clk);cw=0;wait(!idle);wait(idle);repeat(4)@(negedge clk);end endtask
task configure;
begin write(31,0,38'ha08a6412);if(styles!==0||reject)$fatal(1,"BEGIN");
for(l=0;l<13;l=l+1)for(s=0;s<3;s=s+1)write(l,512+s,0);
write(31,1,38'ha08a6412);if(styles!==7||reject)$fatal(1,"COMMIT");end endtask
task frame(input integer st);
begin
 outputs=0;wait(idle);@(negedge clk);style=st;start=1;@(negedge clk);start=0;
 wait(replay_start);busy=1;
 for(j=0;j<32;j=j+1)begin @(negedge nc);rd=j;rv=1;@(posedge nc);while(!rr)@(posedge nc);@(negedge nc);rv=0;end
 busy=0;wait(done);#1;if(!ok||outputs!=32||styles!==7)$fatal(1,"FRAME");
 wait(idle);repeat(8)@(negedge clk);
end endtask
initial begin
 repeat(8)@(negedge clk);reset=0;repeat(1100)@(negedge nc);wait(idle);
 write(31,0,38'ha08a6412);write(31,1,38'ha08a6412);if(!reject||styles!==0)$fatal(1,"PARTIAL_ACCEPTED");
 configure();frame(0);frame(2);configure();frame(1);
 $display("PASS_CONTROL_CDC reload, incomplete rejection, three styles, frame resets, backpressure");$finish;
end
initial begin #5000000;$fatal(1,"TIMEOUT");end
endmodule
