`timescale 1ns/1ps
module tb;
localparam W=640,H=64,NP=W*H;
reg clk=0,rst=1;always #5 clk=~clk;
reg cw=0,cs=0;reg [4:0] cl=0,cn=0;reg [11:0] ca=0;reg [37:0] cd=0;
reg [23:0] id=0;reg iv=0;wire ir;wire [23:0] od;wire ov;
integer ip=0,op=0,cycle=0,start_cycle=0,first_cycle=0,fd,rc,count=0;
reg [31:0] address,lo,hi;
stylenet_top #(.WIDTH(W),.HEIGHT(H)) dut(.clk(clk),.rst(rst),.style(4'd0),
.cfg_we(cw),.cfg_sel(cs),.cfg_layer(cl),.cfg_lane(cn),.cfg_addr(ca),.cfg_data(cd),
.i_data(id),.i_valid(iv),.i_ready(ir),.o_data(od),.o_valid(ov),.o_ready(1'b1),
.st_sel(5'd0),.st_arm(1'b0),.st_fs(1'b0),.st_fe(1'b0),.st_idx(8'd0),.st_s1(),.st_s2(),.st_done(),.st_busy());
always @(posedge clk)begin
cycle=cycle+1;
if(!rst&&iv&&ir)ip=ip+1;
if(!rst&&ov)begin
if(op==0)begin first_cycle=cycle;$display("FIRST %0d",cycle-start_cycle);end
op=op+1;
if(op%W==0)$display("ROW %0d %0d",op/W,cycle-start_cycle);
if(op==NP)begin $display("DONE cycles=%0d first=%0d pixels=%0d",cycle-start_cycle,first_cycle-start_cycle,op);$finish;end
end
end
always @(negedge clk)begin
if(!rst&&count==6951)begin iv=ip<NP;id=24'h479bc3+ip;end
end
initial begin
repeat(5)@(negedge clk);rst=0;
fd=$fopen("cfg.txt","r");if(!fd)$fatal;
while(!$feof(fd))begin
@(negedge clk);rc=$fscanf(fd,"%h %h %h\n",address,lo,hi);
if(rc==3)begin cs=address[31];cl=address[20:16];cn=address[25:21];ca=address[11:0];cd={hi[5:0],lo};cw=1;
@(negedge clk);cw=0;repeat(2)@(negedge clk);end
end
$fclose(fd);@(negedge clk);rst=1;repeat(4)@(negedge clk);rst=0;start_cycle=cycle;count=6951;
end
initial begin #2000000000;$fatal(1,"TIMEOUT");end
endmodule
