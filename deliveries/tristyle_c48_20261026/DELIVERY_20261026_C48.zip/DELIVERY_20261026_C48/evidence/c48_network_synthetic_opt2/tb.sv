`timescale 1ns/1ps
module tb;
localparam W=32,H=24,NFR=6,NP=W*H;
reg clk=0,rst=1;always #5 clk=~clk;
reg [3:0] style=0;reg cw=0,cs=0;reg [4:0] cl=0,cn=0;reg [11:0] ca=0;reg [37:0] cd=0;
reg [23:0] id=0;reg iv=0;wire ir;wire [23:0] od;wire ov;reg ready=0;
integer frame=0,ip,op=0,cycle=0,cf,rc,ncfg;reg [31:0] address,lo,hi;
reg [23:0] inputs[0:NFR*NP-1],expected[0:NFR*NP-1];
stylenet_top #(.WIDTH(W),.HEIGHT(H)) dut(.clk(clk),.rst(rst),.style(style),
.cfg_we(cw),.cfg_sel(cs),.cfg_layer(cl),.cfg_lane(cn),.cfg_addr(ca),.cfg_data(cd),
.i_data(id),.i_valid(iv),.i_ready(ir),.o_data(od),.o_valid(ov),.o_ready(ready),
.st_sel(5'd0),.st_arm(1'b0),.st_fs(1'b0),.st_fe(1'b0),.st_idx(8'd0),.st_s1(),.st_s2(),.st_done(),.st_busy());
always @(negedge clk)begin cycle=cycle+1;ready=(cycle%13<9)&&(cycle%47>3);end
always @(posedge clk)if(!rst&&ov&&ready)begin
 if(op>=NP)$fatal(1,"EXCESS_OUTPUT frame=%0d",frame);
 if(od!==expected[frame*NP+op])$fatal(1,"FINAL_MISMATCH frame=%0d pixel=%0d got=%h expected=%h",frame,op,od,expected[frame*NP+op]);
 op=op+1;end
integer lc0=0;reg [31:0] e0[0:NFR*768-1];
always @(posedge clk)if(!rst&&dut.v0&&dut.r0)begin
 if(lc0>=768)$fatal(1,"LAYER_EXCESS layer=0");
 if(dut.d0!==e0[frame*768+lc0])$fatal(1,"LAYER_MISMATCH layer=0 frame=%0d word=%0d got=%h expected=%h",frame,lc0,dut.d0,e0[frame*768+lc0]);
 lc0=lc0+1;end
integer lc1=0;reg [31:0] e1[0:NFR*576-1];
always @(posedge clk)if(!rst&&dut.v1&&dut.r1)begin
 if(lc1>=576)$fatal(1,"LAYER_EXCESS layer=1");
 if(dut.d1!==e1[frame*576+lc1])$fatal(1,"LAYER_MISMATCH layer=1 frame=%0d word=%0d got=%h expected=%h",frame,lc1,dut.d1,e1[frame*576+lc1]);
 lc1=lc1+1;end
integer lc2=0;reg [31:0] e2[0:NFR*576-1];
always @(posedge clk)if(!rst&&dut.v2&&dut.r2)begin
 if(lc2>=576)$fatal(1,"LAYER_EXCESS layer=2");
 if(dut.d2!==e2[frame*576+lc2])$fatal(1,"LAYER_MISMATCH layer=2 frame=%0d word=%0d got=%h expected=%h",frame,lc2,dut.d2,e2[frame*576+lc2]);
 lc2=lc2+1;end
integer lc3=0;reg [31:0] e3[0:NFR*576-1];
always @(posedge clk)if(!rst&&dut.v3&&dut.r3)begin
 if(lc3>=576)$fatal(1,"LAYER_EXCESS layer=3");
 if(dut.d3!==e3[frame*576+lc3])$fatal(1,"LAYER_MISMATCH layer=3 frame=%0d word=%0d got=%h expected=%h",frame,lc3,dut.d3,e3[frame*576+lc3]);
 lc3=lc3+1;end
integer lc4=0;reg [31:0] e4[0:NFR*576-1];
always @(posedge clk)if(!rst&&dut.v4&&dut.r4)begin
 if(lc4>=576)$fatal(1,"LAYER_EXCESS layer=4");
 if(dut.d4!==e4[frame*576+lc4])$fatal(1,"LAYER_MISMATCH layer=4 frame=%0d word=%0d got=%h expected=%h",frame,lc4,dut.d4,e4[frame*576+lc4]);
 lc4=lc4+1;end
integer lc5=0;reg [31:0] e5[0:NFR*576-1];
always @(posedge clk)if(!rst&&dut.v5&&dut.r5)begin
 if(lc5>=576)$fatal(1,"LAYER_EXCESS layer=5");
 if(dut.d5!==e5[frame*576+lc5])$fatal(1,"LAYER_MISMATCH layer=5 frame=%0d word=%0d got=%h expected=%h",frame,lc5,dut.d5,e5[frame*576+lc5]);
 lc5=lc5+1;end
integer lc6=0;reg [31:0] e6[0:NFR*576-1];
always @(posedge clk)if(!rst&&dut.v6&&dut.r6)begin
 if(lc6>=576)$fatal(1,"LAYER_EXCESS layer=6");
 if(dut.d6!==e6[frame*576+lc6])$fatal(1,"LAYER_MISMATCH layer=6 frame=%0d word=%0d got=%h expected=%h",frame,lc6,dut.d6,e6[frame*576+lc6]);
 lc6=lc6+1;end
integer lc7=0;reg [31:0] e7[0:NFR*576-1];
always @(posedge clk)if(!rst&&dut.v7&&dut.r7)begin
 if(lc7>=576)$fatal(1,"LAYER_EXCESS layer=7");
 if(dut.d7!==e7[frame*576+lc7])$fatal(1,"LAYER_MISMATCH layer=7 frame=%0d word=%0d got=%h expected=%h",frame,lc7,dut.d7,e7[frame*576+lc7]);
 lc7=lc7+1;end
integer lc8=0;reg [31:0] e8[0:NFR*576-1];
always @(posedge clk)if(!rst&&dut.v8&&dut.r8)begin
 if(lc8>=576)$fatal(1,"LAYER_EXCESS layer=8");
 if(dut.d8!==e8[frame*576+lc8])$fatal(1,"LAYER_MISMATCH layer=8 frame=%0d word=%0d got=%h expected=%h",frame,lc8,dut.d8,e8[frame*576+lc8]);
 lc8=lc8+1;end
integer lc9=0;reg [31:0] e9[0:NFR*576-1];
always @(posedge clk)if(!rst&&dut.v9&&dut.r9)begin
 if(lc9>=576)$fatal(1,"LAYER_EXCESS layer=9");
 if(dut.d9!==e9[frame*576+lc9])$fatal(1,"LAYER_MISMATCH layer=9 frame=%0d word=%0d got=%h expected=%h",frame,lc9,dut.d9,e9[frame*576+lc9]);
 lc9=lc9+1;end
integer lc10=0;reg [31:0] e10[0:NFR*2304-1];
always @(posedge clk)if(!rst&&dut.v10&&dut.r10)begin
 if(lc10>=2304)$fatal(1,"LAYER_EXCESS layer=10");
 if(dut.d10!==e10[frame*2304+lc10])$fatal(1,"LAYER_MISMATCH layer=10 frame=%0d word=%0d got=%h expected=%h",frame,lc10,dut.d10,e10[frame*2304+lc10]);
 lc10=lc10+1;end
integer lc11=0;reg [31:0] e11[0:NFR*768-1];
always @(posedge clk)if(!rst&&dut.v11&&dut.r11)begin
 if(lc11>=768)$fatal(1,"LAYER_EXCESS layer=11");
 if(dut.d11!==e11[frame*768+lc11])$fatal(1,"LAYER_MISMATCH layer=11 frame=%0d word=%0d got=%h expected=%h",frame,lc11,dut.d11,e11[frame*768+lc11]);
 lc11=lc11+1;end
integer lc12=0;reg [31:0] e12[0:NFR*576-1];
always @(posedge clk)if(!rst&&dut.v12&&dut.r12)begin
 if(lc12>=576)$fatal(1,"LAYER_EXCESS layer=12");
 if(dut.d12!==e12[frame*576+lc12])$fatal(1,"LAYER_MISMATCH layer=12 frame=%0d word=%0d got=%h expected=%h",frame,lc12,dut.d12,e12[frame*576+lc12]);
 lc12=lc12+1;end
task load_config(input integer p);begin
 cf=$fopen(p==0?"cfg0.txt":"cfg1.txt","r");if(!cf)$fatal(1,"CONFIG_OPEN");ncfg=0;
 while(!$feof(cf))begin @(negedge clk);rc=$fscanf(cf,"%h %h %h\n",address,lo,hi);
 if(rc==3)begin cs=address[31];cl=address[20:16];cn=address[25:21];ca=address[11:0];cd={hi[5:0],lo};cw=1;ncfg=ncfg+1;
 @(negedge clk);cw=0;repeat(2)@(negedge clk);end end $fclose(cf);
 $display("LOADED package=%0d records=%0d",p,ncfg);end endtask
initial begin
 $readmemh("input.hex",inputs);$readmemh("expected.hex",expected);
 $readmemh("layer0.hex",e0);
 $readmemh("layer1.hex",e1);
 $readmemh("layer2.hex",e2);
 $readmemh("layer3.hex",e3);
 $readmemh("layer4.hex",e4);
 $readmemh("layer5.hex",e5);
 $readmemh("layer6.hex",e6);
 $readmemh("layer7.hex",e7);
 $readmemh("layer8.hex",e8);
 $readmemh("layer9.hex",e9);
 $readmemh("layer10.hex",e10);
 $readmemh("layer11.hex",e11);
 $readmemh("layer12.hex",e12);
 repeat(5)@(negedge clk);rst=0;
 for(frame=0;frame<NFR;frame=frame+1)begin
 if(frame%3==0)load_config(frame/3);
 @(negedge clk);rst=1;iv=0;repeat(4)@(negedge clk);op=0;
 lc0=0;
 lc1=0;
 lc2=0;
 lc3=0;
 lc4=0;
 lc5=0;
 lc6=0;
 lc7=0;
 lc8=0;
 lc9=0;
 lc10=0;
 lc11=0;
 lc12=0;
 style=frame%3;rst=0;
 for(ip=0;ip<NP;ip=ip+1)begin
 @(negedge clk);iv=1;id=inputs[frame*NP+ip];@(posedge clk);while(!ir)@(posedge clk);
 @(negedge clk);iv=0;if(ip%17==0)repeat(2)@(negedge clk);end
 wait(op==NP);repeat(16)@(negedge clk);
 if(lc0!=768)$fatal(1,"LAYER_MISSING layer=0");
 if(lc1!=576)$fatal(1,"LAYER_MISSING layer=1");
 if(lc2!=576)$fatal(1,"LAYER_MISSING layer=2");
 if(lc3!=576)$fatal(1,"LAYER_MISSING layer=3");
 if(lc4!=576)$fatal(1,"LAYER_MISSING layer=4");
 if(lc5!=576)$fatal(1,"LAYER_MISSING layer=5");
 if(lc6!=576)$fatal(1,"LAYER_MISSING layer=6");
 if(lc7!=576)$fatal(1,"LAYER_MISSING layer=7");
 if(lc8!=576)$fatal(1,"LAYER_MISSING layer=8");
 if(lc9!=576)$fatal(1,"LAYER_MISSING layer=9");
 if(lc10!=2304)$fatal(1,"LAYER_MISSING layer=10");
 if(lc11!=768)$fatal(1,"LAYER_MISSING layer=11");
 if(lc12!=576)$fatal(1,"LAYER_MISSING layer=12");
 $display("FRAME_PASS frame=%0d style=%0d cycles=%0d",frame,style,cycle);end
 $display("PASS C48_FULL_NETWORK_0_LSB");$finish;end
initial begin #2000000000;$fatal(1,"TIMEOUT");end
endmodule
