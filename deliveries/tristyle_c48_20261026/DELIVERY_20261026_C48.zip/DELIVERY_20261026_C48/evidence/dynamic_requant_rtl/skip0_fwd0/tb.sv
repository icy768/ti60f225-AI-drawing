`timescale 1ns/1ps
module tb;
parameter SKIP=1,FWD=1;
localparam C=48,N=1920,WORDS=N/4;
reg clk=0,rst=1;always #5 clk=~clk;
reg [3:0] style=0;reg cw=0;reg [9:0] ca=0;reg [37:0] cd=0;
reg [25:0] acc=0;reg [7:0] side=0;reg iv=0;wire ir;
wire [31:0] od,os;wire ov;reg ready=0;wire sv;wire [18:0] sa;wire [7:0] sc;
requant #(.COUT(C),.NSTY(3),.SKIP_ADD(SKIP),.FWD(FWD)) dut(
.clk(clk),.rst(rst),.style(style),.cfg_we(cw),.cfg_addr(ca),.cfg_data(cd),
.i_acc(acc),.i_side(side),.i_valid(iv),.i_ready(ir),.o_data(od),.o_side(os),.o_valid(ov),.o_ready(ready),
.st_v(sv),.st_a(sa),.st_ch(sc));
reg [37:0] input0[0:N-1],input1[0:N-1];
reg [63:0] expected0[0:WORDS-1],expected1[0:WORDS-1];
integer cycle=0,phase=0,op=0,frame=0,j,fd,rc;reg [63:0] expected;
always @(negedge clk) begin cycle=cycle+1;ready=((cycle%11)<6)&&((cycle%29)>3);end
always @(posedge clk) if(!rst&&ov&&ready) begin
 if(op>=WORDS)$fatal(1,"EXCESS_OUTPUT");
 expected=phase==0?expected0[op]:expected1[op];
 if({os,od}!==expected)$fatal(1,"MISMATCH phase=%0d frame=%0d word=%0d got=%h expected=%h",phase,frame,op,{os,od},expected);
 op=op+1;
end
task load_config(input integer p);
begin
 fd=$fopen(p==0?"cfg0.txt":"cfg1.txt","r");if(!fd)$fatal(1,"CONFIG_OPEN");
 while(!$feof(fd))begin
  @(negedge clk);rc=$fscanf(fd,"%h %h\n",ca,cd);
  if(rc==2)begin cw=1;@(negedge clk);cw=0;repeat(2)@(negedge clk);end
 end
 $fclose(fd);
end endtask
task reset_frame;
begin @(negedge clk);rst=1;iv=0;repeat(4)@(negedge clk);op=0;rst=0;end
endtask
task run_frame;
begin
 for(j=0;j<N;j=j+1)begin
  @(negedge clk);iv=1;
  {style,acc,side}=phase==0?input0[j]:input1[j];
  @(posedge clk);while(!ir)@(posedge clk);
  @(negedge clk);iv=0;
  // Change style while the low coefficient half is still in flight.
  style=(style+1)%3;
  if(j%9==0)repeat(2)@(negedge clk);
 end
 wait(op==WORDS);repeat(12)@(negedge clk);
end endtask
initial begin
 $readmemh("input0.hex",input0);$readmemh("input1.hex",input1);
 $readmemh("expected0.hex",expected0);$readmemh("expected1.hex",expected1);
 repeat(5)@(negedge clk);rst=0;
 for(phase=0;phase<2;phase=phase+1)begin
  load_config(phase);
  for(frame=0;frame<2;frame=frame+1)begin reset_frame();run_frame();end
 end
 $display("PASS dynamic_requant vectors=%0d output_words=%0d",N*4,WORDS*4);$finish;
end
initial begin #5000000;$fatal(1,"TIMEOUT");end
endmodule
