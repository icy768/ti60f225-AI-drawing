`timescale 1ns/1ps
module tb;
reg clk=0;always #5 clk=~clk;
reg we=0,re=0;reg [11:0] wa=0,ra=0;reg [31:0] wd=0;
wire [31:0] got;reg [31:0] mem[0:3839],expected;
packed_line_ram dut(clk,we,wa,wd,re,ra,got);
integer k,frame,cycle=0,checks=0;reg valid=0;
always @(posedge clk)begin
 if(we)mem[wa]<=wd;
 if(re)expected<=mem[ra];
 valid<=re;
end
always @(negedge clk)if(valid)begin
 if(got!==expected)$fatal(1,"RAM_MISMATCH cycle=%0d addr=%0d got=%h expected=%h",cycle,ra,got,expected);
 checks=checks+1;
end
task tick(input integer wr,input integer a,input integer rd,input integer b,input [31:0] value);
begin @(negedge clk);#1;we=wr;wa=a;re=rd;ra=b;wd=value;cycle=cycle+1;end endtask
initial begin
 for(k=0;k<3840;k=k+1)tick(1,k,0,0,k+13);
 tick(0,0,0,0,0);
 for(frame=0;frame<4;frame=frame+1)begin
  for(k=0;k<3840;k=k+1)begin
   tick(1,k,1,k,32'h80000000+frame*3840+k);
   tick(0,k,1,k,0);
   tick(0,k,1,(k+3839)%3840,0);
   tick(0,k,1,(k*31+5)%3840,0);
  end
  // Restart before a partial 128-bit row has committed.
  for(k=0;k<3;k=k+1)tick(1,k,1,k,32'h40000000+frame*4+k);
 end
 tick(0,0,1,3839,0);tick(0,0,0,0,0);repeat(3)@(negedge clk);
 $display("PASS_PACKED_RAM checks=%0d",checks);$finish;
end
endmodule
