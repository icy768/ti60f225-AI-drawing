# C48动态权重包使用说明

固定主干：`Student("cin",48,norm="affine",res="quarter")`。部署ABI为STN2 v2，profile `0xa08a6412`。新C48 bitstream及配套固件首次部署后，同一ABI内的后续算法更新只替换权重包，无需修改RTL或重新编译固件。旧v21b bitstream不支持本包。

## 从QAT检查点导出

在本项目目录执行（Python 3.10、PyTorch、NumPy）：

```powershell
python -B src/export_c48_package.py --checkpoint out/qat_c48/qat_01800.pt --out out/my_new_package
```

输出目录必须尚不存在。导出器严格加载原C48检查点，检查全部6951条记录的地址顺序、完整覆盖、padding、元数据范围和编解码逐项相等，输出`model.bin`与SHA256清单。不自动宣称画质或上板验收通过。当前QAT1800导出已复核，与训练导出包逐字节一致：83476字节，SHA256 `d214f4d2d67a21f28f3785aebe9c5ce16be0afa9d8950eebc5faaa02c8fa0cc3`。

包包含共享int8卷积、三风格全部M/Bq和各层R/S/S2/K。d2的原始12个共享bias已折入Bq，不能遗漏。槽位顺序为野兽派、梵高、铅笔素描。包头CRC与payload CRC随包生成，固件不固定某次训练的CRC。

## 部署与重载

当前固件从配置Flash偏移`0x200000`读取完整STN2包。使用板卡适用的Flash编程器将`model.bin`写到该权重区，避免覆盖bitstream及其他分区；运行中写Flash前应暂停本板视频/模型读取，板载写入流程和耗时仍待实际验证。新C48 bitstream已完成PnR和生成，尚未板载验证；当前包不能配旧bitstream使用。Efinity的.bit/.hex为文本十六进制工具格式，应由兼容编程器解释，不能按文本大小直接当作Flash裸二进制占用。实测记录与剩余缺口见FINAL_DELIVERY_20261026.md。

串口`w`或关键词模式`reload`触发完整模型重载。它暂停并等待引擎空闲，先校验包，再begin关闭ready、完整写入卷积/仿射/元数据，最后commit，检查三个风格ready均有效后恢复。任一步失败保持暂停，避免混合模型版本。每帧网络复位保留参数；帧内风格锁存，不能混用风格。

改变拓扑、并行布局、数值位宽或ABI时需要新profile和匹配硬件。无需改RTL的保证只适用于此profile范围内、经过量化及对齐验证的新包。

## 复核命令

快速检查完整包只需NumPy：`python -B src/inspect_c48_package.py weights/model.bin`（交付目录内运行）；项目目录使用`out/qat_c48/model_01800.bin`。该命令验证CRC、profile、全部记录覆盖和数值范围，不能替代画质或RTL校验。

```powershell
python -B src/check_c48_loader.py
python -B src/check_c48_control.py
python -B src/sim_dynamic_requant.py
python -B src/sim_c48_network.py --blob out/my_new_package/model.bin --width 32 --height 24 --out out/my_new_package/rtl_check
```

加载器负例验证包含CRC、覆盖、重复记录、profile、移位合法性和padding。控制器检查使用网络stub，不替代真实13层仿真。新增包必须重新做真实权重逐层/最终0 LSB验证与画质评估。640×480 CPU与QAT对齐不能写成640×480 RTL验证。
