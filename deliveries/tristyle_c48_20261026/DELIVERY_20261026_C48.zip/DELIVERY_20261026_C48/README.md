# 三风格 C48 工程交付（尚未完成全部验收）

固定原始C48主干；野兽派、梵高油画、铅笔素描。先读 reports/FINAL_DELIVERY_20261026.md。
新bitstream已完成Efinity PnR及生成，尚未实际烧录/上板验证。G3画质和G4时序未过，FPS和切换耗时未测；不得作为全项通过版本宣传。

- bitstream/tristyle_c48.bit 与 .hex：Efinity 2026.1.132生成的Ti60F225配置文件，保持原工具格式。
- weights/model.bin：完整STN2外部包，83476 B，profile a08a6412；Flash权重区偏移0x200000。同ABI内换包后完整reload，不改RTL或固定CRC。
- checkpoints：冻结FP32及选定QAT1800。06:00冻结未按时执行，真实时间11:04:10已记录。
- src：NumPy整数金标准、包导出器、相关验证源。独立整数推理只需NumPy/Pillow。
- hardware：本次RTL/固件和板级工程；原v21b回退目录未改动。
- evidence：正式评估、样张、整网0 LSB及PnR原始报告。

在本目录运行整数参考：

```powershell
python -B src/infer_integer_c48.py --blob weights/model.bin --image YOUR_INPUT.jpg --out integer_result --trace
```

默认640×480三风格，输出13层trace及最终PNG。out目录须新建。RGB输入使用Pillow LANCZOS中心裁切，测试时保持预处理一致。

导出新的兼容QAT检查点（PyTorch/torchvision需要相互匹配）：

```powershell
python -B src/export_c48_package.py --checkpoint checkpoints/qat_01800.pt --out exported_model
```

导出器加载snapshots/original_backbone中原始未改源码；无需原D盘教师/数据目录。训练及正式评估完整环境仍在原工程，测试程序中的工具/数据路径须按实际环境设置。验证依据及换包步骤见reports/WEIGHT_SWAP_GUIDE.md。没有板载结果；不能把640×480 CPU/QAT对齐写成640×480 RTL对齐。

重建板级工程：设置STYLECAM_EFINITY到Efinity安装根（本机D:/），STYLECAM_BUILD_DIR到独立ASCII目录，依次运行hardware/board/build.py interface、map、pnr、pgm；RISC-V固件工具链由STYLECAM_RISCV_BIN指定。固件构建入口为hardware/board/embedded_sw/soc/software/standalone/stylecam/build_fw.py，具体命令见该脚本；构建输出及容量记录见hardware/board/validation/firmware_build.log。pgm这里只生成配置文件，不执行板卡编程。

SHA256SUMS.json列出交付文件哈希。manifest.json绑定成功PnR所用设计文件、ROM、IP和整网仿真源码身份。

仅检查包的CRC、profile、完整布局和各风格元数据：`python -B src/inspect_c48_package.py weights/model.bin`。
