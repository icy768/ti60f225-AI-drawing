"""Load two synthetic parameter sets and compare requant RTL with scalar integers."""
import hashlib,json,os,random,subprocess
from pathlib import Path
from dynamic_requant_contract import RequantMeta,pack_coefficient,requant
ROOT=Path(__file__).resolve().parents[1];RTL=ROOT/'hardware/rtl'
OUT=ROOT/'out/dynamic_requant_rtl'
BIN=Path(r'D:\fpga\tristyle_fresh_20261016\external_runtime\icarus\mingw64\bin')

TB=r'''`timescale 1ns/1ps
module tb;
parameter SKIP=1,FWD=1;
localparam C=48,N=1920,WORDS=N/4;
reg clk=0,rst=1;always #5 clk=~clk;
reg [3:0] style=0;reg cw=0;reg [9:0] ca=0;reg [37:0] cd=0;
reg [25:0] acc=0;reg [7:0] side=0;reg iv=0;wire ir;
wire [31:0] od,os;wire ov;reg ready=0;wire sv;wire [18:0] sa;wire [7:0] sc;
requant #(.COUT(C),.NSTY(3),.SKIP_ADD(SKIP),.FWD(FWD)) dut(
.clk(clk),.rst(rst),.style(style),.cfg_we(cw),.cfg_addr(ca),.cfg_data(cd),
.i_acc(acc),.i_side(side),.i_valid(iv),.i_ready(ir),.o_data(od),.o_side(os),.o_valid(ov),.o_ready(ready),
.st_v(sv),.st_a(sa),.st_ch(sc));
reg [37:0] input0[0:N-1],input1[0:N-1];
reg [63:0] expected0[0:WORDS-1],expected1[0:WORDS-1];
integer cycle=0,phase=0,op=0,frame=0,j,fd,rc;reg [63:0] expected;
always @(negedge clk) begin cycle=cycle+1;ready=((cycle%11)<6)&&((cycle%29)>3);end
always @(posedge clk) if(!rst&&ov&&ready) begin
 if(op>=WORDS)$fatal(1,"EXCESS_OUTPUT");
 expected=phase==0?expected0[op]:expected1[op];
 if({os,od}!==expected)$fatal(1,"MISMATCH phase=%0d frame=%0d word=%0d got=%h expected=%h",phase,frame,op,{os,od},expected);
 op=op+1;
end
task load_config(input integer p);
begin
 fd=$fopen(p==0?"cfg0.txt":"cfg1.txt","r");if(!fd)$fatal(1,"CONFIG_OPEN");
 while(!$feof(fd))begin
  @(negedge clk);rc=$fscanf(fd,"%h %h\n",ca,cd);
  if(rc==2)begin cw=1;@(negedge clk);cw=0;repeat(2)@(negedge clk);end
 end
 $fclose(fd);
end endtask
task reset_frame;
begin @(negedge clk);rst=1;iv=0;repeat(4)@(negedge clk);op=0;rst=0;end
endtask
task run_frame;
begin
 for(j=0;j<N;j=j+1)begin
  @(negedge clk);iv=1;
  {style,acc,side}=phase==0?input0[j]:input1[j];
  @(posedge clk);while(!ir)@(posedge clk);
  @(negedge clk);iv=0;
  // Change style while the low coefficient half is still in flight.
  style=(style+1)%3;
  if(j%9==0)repeat(2)@(negedge clk);
 end
 wait(op==WORDS);repeat(12)@(negedge clk);
end endtask
initial begin
 $readmemh("input0.hex",input0);$readmemh("input1.hex",input1);
 $readmemh("expected0.hex",expected0);$readmemh("expected1.hex",expected1);
 repeat(5)@(negedge clk);rst=0;
 for(phase=0;phase<2;phase=phase+1)begin
  load_config(phase);
  for(frame=0;frame<2;frame=frame+1)begin reset_frame();run_frame();end
 end
 $display("PASS dynamic_requant vectors=%0d output_words=%0d",N*4,WORDS*4);$finish;
end
initial begin #5000000;$fatal(1,"TIMEOUT");end
endmodule
'''

def main():
    OUT.mkdir(exist_ok=True);rng=random.Random(260600);results=[]
    for skip,fwd in [(1,1),(0,0)]:
        out=OUT/f'skip{skip}_fwd{fwd}';out.mkdir(exist_ok=True)
        for phase in range(2):
            metas=[RequantMeta(phase,16+phase,8,12345+phase*997),
                   RequantMeta(3+phase,20,8,100000-phase*71),RequantMeta(25,31,15,262143)]
            coefs=[];cfg=[]
            for sid in range(3):
                row=[]
                for c in range(48):
                    m=rng.randrange(-12000,12001);b=rng.randrange(-6000,6001)
                    if c%17==0:m=-(1<<17);b=-(1<<19)
                    if c%19==0:m=(1<<17)-1;b=(1<<19)-1
                    row.append((m,b));cfg.append(f'{sid*48+c:x} {pack_coefficient(m,b):010x}')
                coefs.append(row);cfg.append(f'{512+sid:x} {metas[sid].pack():010x}')
            (out/f'cfg{phase}.txt').write_text('\n'.join(cfg)+'\n')
            inputs=[];outputs=[];sides=[]
            for i in range(1920):
                sid=(i//4+i//48)%3;c=i%48
                acc=rng.randrange(-(1<<23),1<<23);side=rng.randrange(256)
                if i%23==0:acc=-(1<<25)
                if i%29==0:acc=(1<<25)-1
                inputs.append(f'{(sid<<34)|((acc&((1<<26)-1))<<8)|side:010x}')
                outputs.append(requant(acc,side,*coefs[sid][c],metas[sid],skip=bool(skip)))
                sides.append(side if fwd else 0)
            expected=[]
            for i in range(0,1920,4):
                word=sum(outputs[i+k]<<(k*8) for k in range(4));sw=sum(sides[i+k]<<(k*8) for k in range(4))
                expected.append(f'{(sw<<32)|word:016x}')
            (out/f'input{phase}.hex').write_text('\n'.join(inputs)+'\n')
            (out/f'expected{phase}.hex').write_text('\n'.join(expected)+'\n')
        (out/'tb.sv').write_text(TB)
        env=os.environ.copy();env['PATH']=str(BIN)+';'+env['PATH']
        cmd=[str(BIN/'iverilog.exe'),'-g2012','-s','tb',f'-Ptb.SKIP={skip}',f'-Ptb.FWD={fwd}',
             '-o','sim.vvp','tb.sv',str(RTL/'requant.v'),str(RTL/'common.v')]
        compile_run=subprocess.run(cmd,cwd=out,env=env,capture_output=True,text=True)
        (out/'compile.log').write_text(compile_run.stdout+compile_run.stderr)
        assert compile_run.returncode==0,compile_run.stderr
        run=subprocess.run([str(BIN/'vvp.exe'),'sim.vvp'],cwd=out,env=env,capture_output=True,text=True,timeout=90)
        (out/'simulation.log').write_text(run.stdout+run.stderr);print(run.stdout,flush=True)
        assert run.returncode==0 and 'PASS dynamic_requant' in run.stdout
        results.append(dict(skip=skip,fwd=fwd,vectors=7680,output_words=1920,max_lsb_error=0,passed=True))
    result=dict(passed=True,scope='Synthetic requant unit only; not full network, QAT or board verification',
                tests=results,parameter_packages=2,frames_per_package=2,backpressure=True,style_changes_in_flight=True,
                frame_reset_keeps_parameters=True,
                source_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in
                               [RTL/'requant.v',RTL/'common.v',Path(__file__),ROOT/'src/dynamic_requant_contract.py']})
    (OUT/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

if __name__=='__main__':main()
