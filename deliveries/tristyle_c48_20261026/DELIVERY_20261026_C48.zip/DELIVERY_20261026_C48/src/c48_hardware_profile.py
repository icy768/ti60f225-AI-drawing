"""Hardware layout identity and complete external parameter mapping for C48."""
import hashlib,json,zlib
from dataclasses import asdict,dataclass
import numpy as np
from dynamic_requant_contract import META_BASE,RequantMeta,pack_coefficient,unpack_coefficient
from weight_package import Record,address,build,parse

@dataclass(frozen=True)
class Layer:
    name:str
    cin:int
    cout:int
    kernel:int
    stride:int=1
    dw:bool=False
    up:bool=False
    skip:bool=False
    fwd:bool=False
    pe:int=1

    @property
    def gi(self):return 3 if self.cin==3 else 4
    @property
    def ni(self):return (self.cin//self.gi)*self.kernel**2
    @property
    def weight_width(self):return self.gi*8*(1 if self.dw else self.pe)
    @property
    def lanes(self):return (self.weight_width+31)//32
    @property
    def weight_depth(self):return self.ni*(1 if self.dw else self.cout//self.pe)

LAYERS=[Layer('e1',3,16,3,2,pe=2),Layer('e2',16,48,3,2,pe=4)]
for b in range(4):
    LAYERS.extend([Layer(f'blocks.{b}.dw',48,48,3,dw=True,fwd=True),
                   Layer(f'blocks.{b}.pw',48,48,1,skip=True,pe=2)])
LAYERS.extend([Layer('d1a',48,48,3,dw=True,up=True),Layer('d1b',48,16,1,pe=2),Layer('d2',16,12,3,pe=6)])
PROFILE_DESCRIPTION=dict(format=2,activation='uint8',weight='int8',acc=26,requant='M18_B20_R5_S5_S25_K18_t40',
                         styles=3,geometry=[asdict(l) for l in LAYERS],packed_line_words=4)
PROFILE_JSON=json.dumps(PROFILE_DESCRIPTION,sort_keys=True,separators=(',',':'))
PROFILE=zlib.crc32(PROFILE_JSON.encode())
PROFILE_SHA256=hashlib.sha256(PROFILE_JSON.encode()).hexdigest()

def canonical_addresses():
    for i,l in enumerate(LAYERS):
        for a in range(l.weight_depth):
            for lane in range(l.lanes):yield address(1,i,lane,a)
        for a in range(3*l.cout):yield address(0,i,0,a)
        for sid in range(3):yield address(0,i,0,META_BASE+sid)

def validate_full_records(records):
    expected=list(canonical_addresses())
    if len(records)!=len(expected) or any(r.address!=a for r,a in zip(records,expected)):
        raise ValueError('incomplete or out-of-order C48 parameter records')
    for r in records:
        sel,i,lane,a=r.fields();l=LAYERS[i]
        if sel and lane==l.lanes-1 and l.weight_width%32:
            if r.data>>(l.weight_width%32):raise ValueError('nonzero padded weight bits')
        if not sel and a>=META_BASE and not l.skip and RequantMeta.unpack(r.data).k:
            raise ValueError('non-residual layer has a skip multiplier')

def weight_rows(l,w):
    w=np.asarray(w)
    expected=(l.cout,1 if l.dw else l.cin,l.kernel,l.kernel)
    if w.shape!=expected or np.any(w<-128) or np.any(w>127):raise ValueError('int8 kernel shape/range')
    if not np.array_equal(w,w.astype(np.int8)):raise ValueError('noninteger weights')
    flat=w.reshape(l.cout,1 if l.dw else l.cin,-1)
    for g in range(l.cin//l.gi):
        for t in range(l.kernel**2):
            if l.dw:
                yield bytes(int(flat[g*l.gi+j,0,t])&255 for j in range(l.gi))
            else:
                for f in range(l.cout//l.pe):
                    yield bytes(int(flat[f*l.pe+p,g*l.gi+j,t])&255 for p in range(l.pe) for j in range(l.gi))

def model_records(layers):
    if len(layers)!=13:raise ValueError('thirteen layers required')
    records=[]
    for i,(l,q) in enumerate(zip(LAYERS,layers)):
        for a,row in enumerate(weight_rows(l,q['weight'])):
            row=row.ljust(l.lanes*4,b'\0')
            for lane in range(l.lanes):records.append(Record(address(1,i,lane,a),int.from_bytes(row[4*lane:4*lane+4],'little')))
        m=np.asarray(q['m']);b=np.asarray(q['bq'])
        if m.shape!=(3,l.cout) or b.shape!=m.shape:raise ValueError('affine parameter shape')
        for sid in range(3):
            for c in range(l.cout):records.append(Record(address(0,i,0,sid*l.cout+c),pack_coefficient(int(m[sid,c]),int(b[sid,c]))))
        for sid in range(3):
            meta=q['meta'][sid]
            if not isinstance(meta,RequantMeta):meta=RequantMeta(**meta)
            records.append(Record(address(0,i,0,META_BASE+sid),meta.pack()))
    validate_full_records(records);return records

def export_blob(layers,model_tag=(0,0)):
    return build(model_records(layers),PROFILE,model_tag)

def load_blob(blob):
    p=parse(blob,PROFILE);records=p['records'];validate_full_records(records);pos=0;layers=[]
    for l in LAYERS:
        w=np.zeros((l.cout,1 if l.dw else l.cin,l.kernel**2),dtype=np.int8)
        for g in range(l.cin//l.gi):
            for t in range(l.kernel**2):
                for f in range(1 if l.dw else l.cout//l.pe):
                    row=b''.join(records[pos+lane].data.to_bytes(4,'little') for lane in range(l.lanes));pos+=l.lanes
                    vals=np.frombuffer(row[:l.weight_width//8],dtype=np.int8)
                    if l.dw:w[g*l.gi:(g+1)*l.gi,0,t]=vals
                    else:w[f*l.pe:(f+1)*l.pe,g*l.gi:(g+1)*l.gi,t]=vals.reshape(l.pe,l.gi)
        m=np.zeros((3,l.cout),np.int64);b=np.zeros_like(m)
        for sid in range(3):
            for c in range(l.cout):m[sid,c],b[sid,c]=unpack_coefficient(records[pos].data);pos+=1
        meta=[RequantMeta.unpack(records[pos+s].data) for s in range(3)];pos+=3
        layers.append(dict(weight=w.reshape(l.cout,1 if l.dw else l.cin,l.kernel,l.kernel),m=m,bq=b,meta=meta))
    assert pos==len(records)
    return layers,p
