"""Proposed loadable requant ABI, independent of Torch and active training.

This scalar specification is preparation for subsequent QAT/RTL integration.
It is NOT evidence of full-network or RTL bit alignment.
"""
from dataclasses import dataclass

META_BASE=512

def signed(value,bits):
    if not 0<=value<(1<<bits):raise ValueError('encoded signed value outside width')
    return value-(1<<bits) if value&(1<<(bits-1)) else value

def check_int(value,lo,hi,name):
    if type(value) is not int or not lo<=value<=hi:raise ValueError(f'{name} outside [{lo},{hi}]')

@dataclass(frozen=True)
class RequantMeta:
    r:int
    s:int
    s2:int
    k:int=0

    def __post_init__(self):
        check_int(self.r,0,25,'R');check_int(self.s,0,31,'S')
        check_int(self.s2,0,self.s,'S2');check_int(self.k,0,(1<<18)-1,'K')
        if self.s-self.s2>16:raise ValueError('bias shift exceeds 16 bits')

    def pack(self):return self.r|(self.s<<5)|(self.s2<<10)|(self.k<<15)

    @classmethod
    def unpack(cls,word):
        check_int(word,0,(1<<33)-1,'metadata including reserved bits')
        return cls(word&31,(word>>5)&31,(word>>10)&31,(word>>15)&((1<<18)-1))

def pack_coefficient(m,bq):
    check_int(m,-(1<<17),(1<<17)-1,'M');check_int(bq,-(1<<19),(1<<19)-1,'Bq')
    return ((m&((1<<18)-1))<<20)|(bq&((1<<20)-1))

def unpack_coefficient(word):
    check_int(word,0,(1<<38)-1,'coefficient')
    return signed(word>>20,18),signed(word&((1<<20)-1),20)

def requant(acc,side,m,bq,meta,skip=False,trace=False):
    check_int(acc,-(1<<25),(1<<25)-1,'acc');check_int(side,0,255,'side')
    pack_coefficient(m,bq)
    a=max(-(1<<18),min((1<<18)-1,acc>>meta.r))
    t=a*m+(bq<<(meta.s-meta.s2))+(side*meta.k if skip else 0)
    if not -(1<<39)<=t<(1<<39):raise ArithmeticError('40-bit intermediate overflow')
    shifted=t>>meta.s;q=max(0,min(255,shifted))
    return dict(a=a,t=t,shifted=shifted,q=q) if trace else q
