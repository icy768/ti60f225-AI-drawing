"""Validate a complete STN2 model before programming, with no PyTorch dependency."""
import argparse,hashlib,json
from pathlib import Path
from c48_hardware_profile import load_blob,LAYERS,PROFILE

def main():
    p=argparse.ArgumentParser();p.add_argument('blob',type=Path);a=p.parse_args()
    data=a.blob.read_bytes();layers,header=load_blob(data)
    rows=[]
    for spec,q in zip(LAYERS,layers):
        rows.append(dict(layer=spec.name,weight_shape=list(q['weight'].shape),
            styles=[dict(R=m.r,S=m.s,S2=m.s2,K=m.k) for m in q['meta']]))
    print(json.dumps(dict(valid_complete_package=True,bytes=len(data),records=len(header['records']),
        profile=f'{PROFILE:08x}',sha256=hashlib.sha256(data).hexdigest(),layers=rows,
        board_verified=False),indent=2))

if __name__=='__main__':main()
