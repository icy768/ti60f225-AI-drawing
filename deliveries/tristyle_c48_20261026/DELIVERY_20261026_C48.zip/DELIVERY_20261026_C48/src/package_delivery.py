"""Assemble the measured C48 engineering delivery, preserving failed gates."""
import datetime,hashlib,json,shutil,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
DEST=ROOT/'DELIVERY_20261026_C48'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(source,target=None):
    source=ROOT/source;target=DEST/(target or source.relative_to(ROOT))
    target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
def tree(source,target=None,ignore=None):
    shutil.copytree(ROOT/source,DEST/(target or source),ignore=ignore,dirs_exist_ok=True)

def main():
    DEST.mkdir(exist_ok=False)
    board=ROOT/'hardware/board';build=ROOT/'hardware/build'
    # Check the exact project inputs used by the successful map/PnR/pgm.
    binding={};ns={'e':'http://www.efinixinc.com/enf_proj'}
    for e in ET.parse(board/'ti60f225_oob.xml').findall('.//e:design_file',ns):
        name=e.get('name');a=board/name;b=build/name
        assert a.is_file() and b.is_file(),name
        assert sha(a)==sha(b),('build/source mismatch',name)
        binding[name]=sha(a)
    for folder in ['fw_rom','ip','model']:
        for a in (board/folder).rglob('*'):
            if not a.is_file():continue
            rel=a.relative_to(board)
            b=build/(a.name if folder=='fw_rom' else rel)
            assert b.is_file() and sha(a)==sha(b),str(rel)
            binding[str(rel)]=sha(a)
    rtl_check=json.loads((ROOT/'out/c48_network_qat1800_opt2_w640/result.json').read_text())
    for key,value in rtl_check['source_sha256'].items():
        if key.startswith('hardware\\rtl\\'):
            name=Path(key).name
            assert sha(board/'rtl'/name)==value,('simulation/project mismatch',name)
    for ext in ['bit','hex']:
        copy(Path(f'hardware/build/outflow/ti60f225_oob.{ext}'),Path(f'bitstream/tristyle_c48.{ext}'))
    copy(Path('out/qat_c48/model_01800.bin'),Path('weights/model.bin'))
    copy(Path('out/export_qat01800_portable/manifest.json'),Path('weights/manifest.json'))
    copy(Path('out/qat_c48/qat_01800.pt'),Path('checkpoints/qat_01800.pt'))
    tree(Path('out/frozen_20261026_0600'),Path('checkpoints/frozen_fp32'))
    copy(Path('out/FLOAT_TUNING_STOP.json'))
    for n in ['infer_integer_c48.py','integer_c48.py','c48_hardware_profile.py','dynamic_requant_contract.py',
              'weight_package.py','export_c48_package.py','inspect_c48_package.py','qat_c48.py','sim_c48_network.py',
              'check_c48_loader.py','check_c48_control.py','sim_dynamic_requant.py','check_packed_line.py',
              'verify_qat_fullsize.py','measure_rtl_throughput.py','analyze_rtl_throughput.py','package_delivery.py']:
        copy(Path('src')/n)
    tree(Path('snapshots/original_backbone'))
    tree(Path('hardware/rtl'));tree(Path('hardware/firmware'))
    for n in ['rtl','ip','embedded_sw','fw_rom']:
        tree(Path('hardware/board')/n,ignore=shutil.ignore_patterns('__pycache__','*.o','*.d'))
    # Only runtime display tables and the selected model are needed; obsolete IN tables are omitted.
    for n in ['camera_gamma.mem','font8x16.mem','osd_text.mem','net_blob.bin','integration.json','validation.json']:
        copy(Path('hardware/board/model')/n)
    for n in ['build.py','ti60f225_oob.xml','ti60f225_oob.peri.xml','ti60f225_oob.sdc']:
        copy(Path('hardware/board')/n)
    tree(Path('hardware/board/validation'))
    for n in ['ti60f225_oob.place.rpt','ti60f225_oob.route.rpt','ti60f225_oob.timing.rpt',
              'ti60f225_oob.hier_util.rpt','ti60f225_oob.cdc.rpt','ti60f225_oob.log']:
        copy(Path('hardware/build/outflow')/n,Path('evidence/pnr')/n)
    for n in ['qat_eval','qat_camera_01800','qat_camera_02400','candidate_selection']:
        tree(Path('out')/n,Path('evidence')/n)
    for n in ['dynamic_requant_rtl','c48_network_synthetic_opt2','c48_network_qat1800_opt2_w640',
              'qat_fullsize_integer','c48_loader_check','c48_control_check','packed_line_check']:
        folder=ROOT/'out'/n
        if not folder.exists():continue
        for p in folder.rglob('*'):
            if p.is_file() and (p.suffix in ['.json','.log','.sv'] or 'rtl_snapshot' in p.parts):
                copy(p.relative_to(ROOT),Path('evidence')/n/p.relative_to(folder))
    for n in ['FINAL_DELIVERY_20261026.md','WEIGHT_SWAP_GUIDE.md','FREEZE_QAT_20261026.md',
              'DYNAMIC_REQUANT_DESIGN.md','USER_UPDATE_20261025_2205.md','source_integrity.json','c48_memory_budget.json']:
        copy(Path('reports')/n)
    for n in ['CODEX_TASK_TRISTYLE_C48.md','REPORT_20261025.md','input_manifest.json']:
        copy(Path('snapshots')/n)
    if (ROOT/'out/rtl_throughput_640x64/result.json').exists():
        copy(Path('out/rtl_throughput_640x64/result.json'),Path('evidence/rtl_throughput_640x64/result.json'))
    assert sha(DEST/'weights/model.bin')==sha(DEST/'hardware/board/model/net_blob.bin')
    manifest=dict(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        profile='a08a6412',fp32_frozen_actual_at='2026-10-26T11:04:10+08:00',
        requested_freeze_missed=True,selected_qat_step=1800,board_verified=False,
        build_input_sha256=binding,rtl_real_weight_regression=rtl_check,
        resources=dict(xlr=[60273,60800],ram=[251,256],dsp=[127,160]),
        constrained_setup_min_ns=.398,constrained_hold_min_ns=.026,
        net_clock_setup_slack_ns=.689,net_clock_mhz=150,
        bitstream_generated=True,quality_g3_passed=False,quality_g4_passed=False,
        fps_15_verified=False,switch_100ms_verified=False,fullsize_rtl_verified=False)
    (DEST/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    (DEST/'requirements_integer.txt').write_text('numpy>=1.24\nPillow>=10\n')
    (DEST/'requirements_export.txt').write_text('numpy>=1.24\nPillow>=10\ntorch>=2.7\ntorchvision>=0.22\n')
    (DEST/'README.md').write_text('''# 三风格 C48 工程交付（尚未完成全部验收）

固定原始C48主干；野兽派、梵高油画、铅笔素描。先读 reports/FINAL_DELIVERY_20261026.md。
新bitstream已完成Efinity PnR及生成，尚未实际烧录/上板验证。G3画质和G4时序未过，FPS和切换耗时未测；不得作为全项通过版本宣传。

- bitstream/tristyle_c48.bit 与 .hex：Efinity 2026.1.132生成的Ti60F225配置文件，保持原工具格式。
- weights/model.bin：完整STN2外部包，83476 B，profile a08a6412；Flash权重区偏移0x200000。同ABI内换包后完整reload，不改RTL或固定CRC。
- checkpoints：冻结FP32及选定QAT1800。06:00冻结未按时执行，真实时间11:04:10已记录。
- src：NumPy整数金标准、包导出器、相关验证源。独立整数推理只需NumPy/Pillow。
- hardware：本次RTL/固件和板级工程；原v21b回退目录未改动。
- evidence：正式评估、样张、整网0 LSB及PnR原始报告。

在本目录运行整数参考：

```powershell
python -B src/infer_integer_c48.py --blob weights/model.bin --image YOUR_INPUT.jpg --out integer_result --trace
```

默认640×480三风格，输出13层trace及最终PNG。out目录须新建。RGB输入使用Pillow LANCZOS中心裁切，测试时保持预处理一致。

仅检查包的CRC、profile、完整布局和各风格元数据：`python -B src/inspect_c48_package.py weights/model.bin`。

导出新的兼容QAT检查点（PyTorch/torchvision需要相互匹配）：

```powershell
python -B src/export_c48_package.py --checkpoint checkpoints/qat_01800.pt --out exported_model
```

导出器加载snapshots/original_backbone中原始未改源码；无需原D盘教师/数据目录。训练及正式评估完整环境仍在原工程，测试程序中的工具/数据路径须按实际环境设置。验证依据及换包步骤见reports/WEIGHT_SWAP_GUIDE.md。没有板载结果；不能把640×480 CPU/QAT对齐写成640×480 RTL对齐。

重建板级工程：设置STYLECAM_EFINITY到Efinity安装根（本机D:/），STYLECAM_BUILD_DIR到独立ASCII目录，依次运行hardware/board/build.py interface、map、pnr、pgm；RISC-V固件工具链由STYLECAM_RISCV_BIN指定。固件构建入口为hardware/board/embedded_sw/soc/software/standalone/stylecam/build_fw.py，具体命令见该脚本；构建输出及容量记录见hardware/board/validation/firmware_build.log。pgm这里只生成配置文件，不执行板卡编程。

SHA256SUMS.json列出交付文件哈希。manifest.json绑定成功PnR所用设计文件、ROM、IP和整网仿真源码身份。
''',encoding='utf-8')
    checks={str(p.relative_to(DEST)):sha(p) for p in DEST.rglob('*') if p.is_file()}
    (DEST/'SHA256SUMS.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
    print(json.dumps(dict(delivery=str(DEST),files=len(checks),bytes=sum(p.stat().st_size for p in DEST.rglob('*') if p.is_file())),indent=2))

if __name__=='__main__':main()
