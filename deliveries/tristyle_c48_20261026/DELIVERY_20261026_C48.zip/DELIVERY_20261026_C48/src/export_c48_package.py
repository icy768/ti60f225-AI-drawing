"""Export compatible QAT weights without changing RTL or a model-specific CRC."""
import argparse, hashlib, json
from pathlib import Path
import numpy as np
import torch
from qat_c48 import QATC48
from c48_hardware_profile import export_blob, load_blob, PROFILE, PROFILE_SHA256

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--checkpoint',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True,help='new directory for model.bin and manifest.json')
    a=p.parse_args()
    cp=torch.load(a.checkpoint,map_location='cpu',weights_only=True)
    state={k[len('student.'):]:v for k,v in cp['net'].items() if k.startswith('student.')}
    net=QATC48(state,cp['contract']).eval();net.load_state_dict(cp['net'],strict=True)
    layers=net.export_layers();blob=export_blob(layers);decoded,header=load_blob(blob)
    for x,y in zip(layers,decoded):
        for key in ('weight','m','bq'):assert np.array_equal(x[key],y[key]),key
        assert x['meta']==y['meta']
    a.out.mkdir(parents=True,exist_ok=False)
    (a.out/'model.bin').write_bytes(blob)
    manifest=dict(format='STN2',profile=f'{PROFILE:08x}',profile_sha256=PROFILE_SHA256,
        checkpoint=str(a.checkpoint.resolve()),checkpoint_sha256=hashlib.sha256(a.checkpoint.read_bytes()).hexdigest(),
        frozen_source_sha256=cp.get('source_sha256'),qat_step=cp.get('step'),
        blob_sha256=hashlib.sha256(blob).hexdigest(),bytes=len(blob),records=len(header['records']),
        contains=['shared int8 convolution','all styles M/Bq','all styles R/S/S2/K'],
        codec_roundtrip_verified=True,quality_evaluated_by_this_export=False,board_verified=False)
    (a.out/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print(json.dumps(manifest,indent=2))

if __name__=='__main__':main()
