"""Standalone CPU integer oracle; only NumPy and Pillow are required."""
import argparse,hashlib,json,time
from pathlib import Path
import numpy as np
from PIL import Image,ImageOps
from c48_hardware_profile import load_blob,PROFILE
from integer_c48 import run

def main():
    p=argparse.ArgumentParser();p.add_argument('--blob',type=Path,required=True)
    p.add_argument('--image',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    p.add_argument('--width',type=int,default=640);p.add_argument('--height',type=int,default=480)
    p.add_argument('--style',type=int,choices=[0,1,2]);p.add_argument('--trace',action='store_true')
    a=p.parse_args();assert a.width>0 and a.height>0 and a.width%4==0 and a.height%4==0
    layers,_=load_blob(a.blob.read_bytes());a.out.mkdir(parents=True,exist_ok=False)
    im=np.array(ImageOps.fit(Image.open(a.image).convert('RGB'),(a.width,a.height),method=Image.Resampling.LANCZOS))
    Image.fromarray(im).save(a.out/'input.png');rows=[];t0=time.time()
    for sid in ([a.style] if a.style is not None else range(3)):
        y,tr=run(layers,im,sid,trace=True);Image.fromarray(y).save(a.out/f'style{sid}.png')
        if a.trace:np.savez_compressed(a.out/f'style{sid}_layers.npz',**{f'layer{i}':v for i,v in enumerate(tr)})
        rows.append(dict(style=sid,output_rgb_sha256=hashlib.sha256(y.tobytes()).hexdigest(),
            layer_int64_sha256=[hashlib.sha256(v.astype('<i8').tobytes()).hexdigest() for v in tr]))
    r=dict(profile=f'{PROFILE:08x}',blob_sha256=hashlib.sha256(a.blob.read_bytes()).hexdigest(),
        input_rgb_sha256=hashlib.sha256(im.tobytes()).hexdigest(),size=[a.width,a.height],results=rows,
        seconds=time.time()-t0,scope='Independent CPU int64 inference; not hardware measurement')
    (a.out/'manifest.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))

if __name__=='__main__':main()
