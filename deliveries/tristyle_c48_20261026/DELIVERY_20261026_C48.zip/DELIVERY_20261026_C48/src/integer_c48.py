"""CPU int64 reference for the original 13-layer C48 graph and loaded STN2 values."""
import numpy as np
from c48_hardware_profile import LAYERS,load_blob

def conv_int(x,w,stride,dw):
    k=w.shape[-1];p=k//2
    padded=np.pad(x.astype(np.int64),((0,0),(p,p),(p,p)))
    windows=np.lib.stride_tricks.sliding_window_view(padded,(k,k),axis=(1,2))[:,::stride,::stride]
    if dw:return np.einsum('chwij,cij->chw',windows,w[:,0].astype(np.int64),optimize=True,dtype=np.int64)
    return np.einsum('chwij,ocij->ohw',windows,w.astype(np.int64),optimize=True,dtype=np.int64)

def run(layers,image,style,trace=False):
    if image.dtype!=np.uint8 or image.ndim!=3 or image.shape[-1]!=3:raise ValueError('HWC uint8 RGB input required')
    if style not in (0,1,2):raise ValueError('style')
    x=image.transpose(2,0,1);skip=None;traces=[]
    for l,q in zip(LAYERS,layers):
        if l.up:x=x.repeat(2,1).repeat(2,2)
        if l.fwd:skip=x.copy()
        acc=conv_int(x,q['weight'],l.stride,l.dw)
        if np.any(acc<-(1<<25)) or np.any(acc>=(1<<25)):raise ArithmeticError('acc26 overflow')
        m=q['meta'][style];a=np.clip(acc>>m.r,-(1<<18),(1<<18)-1)
        t=a*q['m'][style,:,None,None]+(q['bq'][style,:,None,None]<<(m.s-m.s2))
        if l.skip:t=t+skip.astype(np.int64)*m.k
        if np.any(t<-(1<<39)) or np.any(t>=(1<<39)):raise ArithmeticError('requant40 overflow')
        x=np.clip(t>>m.s,0,255).astype(np.uint8)
        if trace:traces.append(x.copy())
    c,h,w=x.shape;assert c==12
    rgb=x.reshape(3,2,2,h,w).transpose(0,3,1,4,2).reshape(3,2*h,2*w).transpose(1,2,0)
    return (rgb,traces) if trace else rgb

def run_blob(blob,image,style,trace=False):
    layers,_=load_blob(blob);return run(layers,image,style,trace)
