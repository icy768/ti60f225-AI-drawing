"""Separate a short-frame interior timing window from the accelerated drain."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FOLDER = ROOT / 'out/rtl_throughput_640x64'
raw = json.loads((FOLDER / 'result.json').read_text())
rows = dict(raw['rows'])
assert len(rows) == 64
for name, expected in raw['source_sha256'].items():
    assert hashlib.sha256((ROOT / 'hardware/board/rtl' / name).read_bytes()).hexdigest() == expected
windows = [rows[i + 4] - rows[i] for i in range(8, 40, 4)]
assert len(set(windows)) == 1
period = (rows[40] - rows[8]) / 32
full_steady_cycles = period * 480
overhead = rows[64] - period * 64
analysis = dict(scope='640x64 interior row timing extrapolation only; not full-frame or board verification',
    window_rows=[8, 40], four_row_cycles=windows,
    cycles_per_output_row=period, extrapolated_480row_steady_cycles=full_steady_cycles,
    extrapolated_480row_steady_fps=150e6 / full_steady_cycles,
    observed_64row_total_cycles=rows[64], observed_64row_overhead_cycles=overhead,
    conditional_480row_fps_if_same_overhead=150e6 / (full_steady_cycles + overhead),
    legacy_last16_window_fps=raw['extrapolated_480row_steady_fps'],
    legacy_last16_note='Includes end-of-frame drain; must not be treated as steady-state FPS.',
    input_continuous=True, output_always_ready=True,
    image_correctness_checked=False, fullsize_rtl_verified=False, board_verified=False,
    pnr_source_identity_verified=True)
(FOLDER / 'analysis.json').write_text(json.dumps(analysis, indent=2), encoding='utf-8')
print(json.dumps(analysis, indent=2))
