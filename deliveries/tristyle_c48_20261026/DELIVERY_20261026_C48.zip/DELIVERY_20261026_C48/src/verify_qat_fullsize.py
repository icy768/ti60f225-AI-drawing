"""Full-resolution CPU integer vs QAT forward plus shift-only requant comparison."""
import json,copy,time,hashlib
import numpy as np,torch
from PIL import Image,ImageOps
from qat_c48 import QATC48
from c48_hardware_profile import load_blob
from integer_c48 import run
from evaluate_joint_candidates import ROOT,REFERENCE,GATE
torch.set_num_threads(4);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
c=torch.load(ROOT/'out/qat_c48/qat_01800.pt',map_location='cpu',weights_only=True)
state=torch.load(ROOT/'out/frozen_20261026_0600/student_fp32.pt',map_location='cpu',weights_only=True)
net=QATC48(state,c['contract']).cuda().eval();net.load_state_dict(c['net'])
blob=ROOT/'out/qat_c48/model_01800.bin';layers,_=load_blob(blob.read_bytes())
styles=json.loads(GATE.read_text())['styles'];files=json.loads((REFERENCE/f'{styles[0]}.json').read_text())['source_files']
out=ROOT/'out/qat_fullsize_integer';out.mkdir(exist_ok=True);rows=[];t0=time.time()
with torch.no_grad():
 for sid in range(3):
  path=files[[1,7,32][sid]];im=np.asarray(ImageOps.fit(Image.open(path).convert('RGB'),(640,480),method=Image.Resampling.LANCZOS)).copy()
  x=torch.from_numpy(im).permute(2,0,1)[None].cuda().float()/255
  y,trace=net(x,sid,trace=True);gold,gt=run(layers,im,sid,trace=True)
  for i,(a,b) in enumerate(zip(trace,gt)):assert np.array_equal(a[0].cpu().numpy(),b),(sid,i)
  assert np.array_equal((y[0].permute(1,2,0)*255).round().byte().cpu().numpy(),gold)
  Image.fromarray(gold).save(out/f'style{sid}.png')
  rows.append(dict(style=sid,input=path,all_layers_max_lsb=0,final_max_lsb=0));print('FULLSIZE_PASS',sid,round(time.time()-t0,2),flush=True)
(out/'result.json').write_text(json.dumps(dict(size=[640,480],frames=3,all_layers=True,passed=True,rows=rows,scope='CPU int64 vs QAT exact forward; NOT full-size RTL',blob_sha256=hashlib.sha256(blob.read_bytes()).hexdigest(),seconds=time.time()-t0),indent=2))
