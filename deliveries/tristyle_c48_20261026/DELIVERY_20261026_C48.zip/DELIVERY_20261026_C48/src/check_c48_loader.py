"""Exercise the exact firmware parser on full real models and malformed packages."""
import subprocess,json,struct,zlib,hashlib
from pathlib import Path
from c48_hardware_profile import load_blob
ROOT=Path(__file__).resolve().parents[1]
out=ROOT/'out/c48_loader_check';out.mkdir(exist_ok=True)
src=ROOT/'hardware/firmware';exe=out/'check.exe'
c=subprocess.run([r'C:\mingw64\bin\gcc.exe','-std=c99','-O2','-Wall','-Wextra','-Werror',str(src/'check_package_host.c'),'-o',str(exe)],capture_output=True,text=True);assert c.returncode==0,c.stderr
rows=[]
for step in [0,1800]:
 p=ROOT/f'out/qat_c48/model_{step:05d}.bin';b=p.read_bytes();layers,head=load_blob(b);dest=out/f'loaded_{step}.txt'
 r=subprocess.run([str(exe),str(p),str(dest)],capture_output=True,text=True);assert r.returncode==0,r.stdout
 expected=''.join(f'{a.address:08x} {a.data&0xffffffff:08x} {a.data>>32:02x}\n' for a in head['records']);assert dest.read_text()==expected
 rows.append(dict(case=f'real_{step}',passed=True,records=len(head['records']),sha256=hashlib.sha256(b).hexdigest()))
def fixed(b):
 h=list(struct.unpack_from('<16I',b));h[3]=len(b);h[4]=(len(b)-64)//12;h[8]=zlib.crc32(b[64:]);h[9]=0;h[9]=zlib.crc32(struct.pack('<16I',*h));return struct.pack('<16I',*h)+b[64:]
cases={}
cases['crc_corrupt']=b[:100]+bytes([b[100]^1])+b[101:]
cases['truncated']=b[:-1]
cases['missing_weight_correct_crc']=fixed(b[:64]+b[76:])
cases['duplicate_weight_correct_crc']=fixed(b[:76]+b[64:76]+b[76:])
v=bytearray(b);v[28]^=1;cases['profile_correct_crc']=fixed(v)
v=bytearray(b)
for pos in range(64,len(v),12):
 if struct.unpack_from('<I',v,pos)[0]==512:
  struct.pack_into('<II',v,pos+4,31,0);break
cases['invalid_shift_correct_crc']=fixed(v)
v=bytearray(b);struct.pack_into('<I',v,76+4,0x00ffffff);cases['padding_correct_crc']=fixed(v)
for name,data in cases.items():
 p=out/(name+'.bin');p.write_bytes(data);r=subprocess.run([str(exe),str(p)],capture_output=True,text=True)
 assert r.returncode!=0 and 'written=0' in r.stdout,(name,r.stdout)
 rows.append(dict(case=name,passed=True,result=r.stdout.strip()))
(out/'result.json').write_text(json.dumps(dict(passed=True,scope='C firmware parser exact record output plus negative packages; no board',cases=rows,parser_sha256=hashlib.sha256((src/'c48_package.h').read_bytes()).hexdigest()),indent=2));print(json.dumps(rows,indent=2))
