"""Exact integer-forward QAT adapter; the original C48 Student is unchanged."""
import sys
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
from c48_hardware_profile import LAYERS
from dynamic_requant_contract import RequantMeta
_original = Path(__file__).resolve().parents[1]/'snapshots'/'original_backbone'
sys.path.insert(0,str(_original) if _original.is_dir() else r'D:\ClaudeTest\st_backbone_diag')
import exp2_mechanism as X

class ExactSTE(torch.autograd.Function):
    @staticmethod
    def forward(ctx,proxy,exact):return exact
    @staticmethod
    def backward(ctx,grad):return grad,None

def ste_round(x):return ExactSTE.apply(x,x.round())

def norm_module(net,index):
    if index==0:return net.n_e1
    if index==1:return net.n_e2
    if 2<=index<=9:return getattr(net.blocks[(index-2)//2],'n1' if index%2==0 else 'n2')
    if index==10:return net.n_d1a
    if index==11:return net.n_d1b
    return None

def float_trace(net,x,sid):
    trace=[];skip=None
    for i,l in enumerate(LAYERS):
        if l.up:x=F.interpolate(x,scale_factor=2,mode='nearest')
        if l.fwd:skip=x
        x=net.get_submodule(l.name)(x,sid);n=norm_module(net,i)
        if n is not None:x=n(x,sid)
        if l.skip:x=x+skip
        if i!=12:x=F.relu(x)
        trace.append(x)
    return F.pixel_shuffle(x,2),trace

class QATC48(torch.nn.Module):
    def __init__(self,state,contract):
        super().__init__();self.student=X.Student('cin',48,norm='affine',res='quarter')
        self.student.load_state_dict(state);self.contract=contract
        self.register_buffer('activation_scale',torch.tensor(contract['activation_scale'],dtype=torch.float32))
        for i,ws in enumerate(contract['weight_scale']):self.register_buffer(f'ws{i}',torch.tensor(ws,dtype=torch.float32))

    def coefficients(self,i,sid):
        n=norm_module(self.student,i);conv=self.student.get_submodule(LAYERS[i].name)
        gamma=n.g[sid] if n is not None else torch.ones_like(conv.b)
        beta=n.b[sid] if n is not None else conv.b
        sx=(1/255) if i==0 else self.activation_scale[i-1,sid]
        sy=self.activation_scale[i,sid];r,s,s2,k=self.contract['meta'][i][sid]
        m=ste_round(gamma*getattr(self,f'ws{i}')*sx/sy*(2.**(r+s))).clamp(-(1<<17),(1<<17)-1)
        b=ste_round(beta/sy*(2.**s2)).clamp(-(1<<19),(1<<19)-1)
        return m,b,r,s,s2,k

    def forward(self,image,sid,trace=False):
        x=ste_round(image*255).clamp(0,255);skip=None;traces=[]
        for i,l in enumerate(LAYERS):
            if l.up:x=F.interpolate(x,scale_factor=2,mode='nearest')
            if l.fwd:skip=x
            w=self.student.get_submodule(l.name).w[0]
            wi=ste_round(w/getattr(self,f'ws{i}')[:,None,None,None]).clamp(-127,127)
            acc=F.conv2d(x,wi,None,l.stride,l.kernel//2,groups=l.cin if l.dw else 1)
            m,b,r,s,s2,k=self.coefficients(i,sid)
            # Integer arithmetic provides exact forward values; the proxy only supplies gradients.
            ai=torch.div(acc.detach().round().to(torch.int64),1<<r,rounding_mode='floor').clamp(-(1<<18),(1<<18)-1)
            t=ai*m.detach().to(torch.int64)[None,:,None,None]+(b.detach().to(torch.int64)[None,:,None,None]<<(s-s2))
            if l.skip:t=t+skip.detach().round().to(torch.int64)*k
            exact=torch.div(t,1<<s,rounding_mode='floor').clamp(0,255).float()
            a=ExactSTE.apply(acc/(2.**r),ai.float()).clamp(-(1<<18),(1<<18)-1)
            proxy=a*m[None,:,None,None]+b[None,:,None,None]*(2.**(s-s2))
            if l.skip:proxy=proxy+skip*k
            proxy=(proxy/(2.**s)).clamp(0,255)
            x=ExactSTE.apply(proxy,exact)
            if trace:traces.append(x.detach())
        output=F.pixel_shuffle(x/255,2)
        return (output,traces) if trace else output

    @torch.no_grad()
    def export_layers(self):
        out=[]
        for i,l in enumerate(LAYERS):
            conv=self.student.get_submodule(l.name);ws=getattr(self,f'ws{i}')
            weight=(conv.w[0]/ws[:,None,None,None]).round().clamp(-127,127).cpu().numpy().astype(np.int8)
            ms=[];bs=[];metas=[]
            for sid in range(3):
                m,b,r,s,s2,k=self.coefficients(i,sid);ms.append(m.cpu().numpy().astype(np.int64));bs.append(b.cpu().numpy().astype(np.int64));metas.append(RequantMeta(r,s,s2,k))
            out.append(dict(weight=weight,m=np.stack(ms),bq=np.stack(bs),meta=metas))
        return out

@torch.no_grad()
def calibrate(net,images):
    scales=np.zeros((13,3),np.float64);weights=[]
    for i,l in enumerate(LAYERS):
        w=net.get_submodule(l.name).w[0].detach().cpu().numpy()
        weights.append(np.maximum(np.abs(w).reshape(l.cout,-1).max(1)/127,1e-9))
    for sid in range(3):
        for x in images:
            y,trace=float_trace(net,x,sid)
            assert torch.equal(y,net(x,sid)),'Adapter changed the float backbone'
            for i,a in enumerate(trace[:-1]):scales[i,sid]=max(scales[i,sid],float(torch.quantile(a.flatten(),.9999))/255)
        scales[-1,sid]=1/255
    scales=np.maximum(scales,1e-7);metas=[]
    for i,l in enumerate(LAYERS):
        w=net.get_submodule(l.name).w[0].detach().cpu().numpy();wi=np.clip(np.rint(w/weights[i][:,None,None,None]),-127,127)
        bound=255*np.abs(wi).reshape(l.cout,-1).sum(1).max()
        r=max(0,int(np.ceil(np.log2(max(bound,1)/((1<<18)-1)))))
        n=norm_module(net,i);conv=net.get_submodule(l.name);row=[]
        for sid in range(3):
            gamma=n.g[sid].detach().cpu().numpy() if n is not None else np.ones(l.cout)
            beta=n.b[sid].detach().cpu().numpy() if n is not None else conv.b.detach().cpu().numpy()
            sx=1/255 if i==0 else scales[i-1,sid];sy=scales[i,sid]
            gain=gamma*weights[i]*sx/sy*(2**r);bias=beta/sy
            s=min(30,int(np.floor(np.log2(.9*((1<<17)-1)/max(np.abs(gain).max(),1e-12)))))
            kr=scales[i-2,sid]/sy if l.skip else 0
            if l.skip:s=min(s,int(np.floor(np.log2(.9*((1<<18)-1)/max(kr,1e-12)))))
            s2=min(s,16,int(np.floor(np.log2(.9*((1<<19)-1)/max(np.abs(bias).max(),1e-12)))))
            s=min(s,s2+16);assert s>=0 and s2>=0
            k=int(np.rint(kr*2**s));RequantMeta(r,s,s2,k);row.append([r,s,s2,k])
        metas.append(row)
    return dict(activation_scale=scales.tolist(),weight_scale=[w.tolist() for w in weights],meta=metas,
                calibration='32 fixed training-cache source crops; max per-image 99.99 percentile; no held-out images',
                arithmetic='uint8/int8 acc26 sat19 M18/B20 dynamic R/S/S2/K exact int64 forward')
