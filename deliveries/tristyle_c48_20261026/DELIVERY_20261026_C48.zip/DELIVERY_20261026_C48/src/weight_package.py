"""Versioned external weight container; proposed ABI for the fixed C48 model.

No checkpoint CRC or fixed record count is compiled into this codec. Hardware
layout/coverage validation is a separate integration requirement. This module
alone must not authorize a board load.
"""
import struct,zlib
from dataclasses import dataclass
from dynamic_requant_contract import META_BASE,RequantMeta

MAGIC=0x324E5453  # little-endian ASCII STN2
VERSION=2
HEADER=struct.Struct('<16I');RECORD=struct.Struct('<III')
MAX_BYTES=500000
COUT=(16,48,48,48,48,48,48,48,48,48,48,16,12)

@dataclass(frozen=True)
class Record:
    address:int
    data:int

    def fields(self):
        if type(self.address) is not int or not 0<=self.address<2**32:raise ValueError('address word')
        if type(self.data) is not int or not 0<=self.data<2**38:raise ValueError('38-bit data')
        if self.address&~0x83FF0FFF:raise ValueError('reserved address bits')
        sel=self.address>>31;layer=(self.address>>16)&31;lane=(self.address>>21)&31;addr=self.address&4095
        if layer>=13:raise ValueError('layer')
        if sel:
            if self.data>=2**32:raise ValueError('convolution word has nonzero high bits')
        else:
            if lane:raise ValueError('requant lane must be zero')
            if META_BASE<=addr<META_BASE+3:RequantMeta.unpack(self.data)
            elif not 0<=addr<3*COUT[layer]:raise ValueError('requant slot')
        return sel,layer,lane,addr

    def bytes(self):
        self.fields()
        return RECORD.pack(self.address,self.data&0xffffffff,self.data>>32)

def address(sel,layer,lane,addr):
    if sel not in (0,1) or not 0<=layer<13 or not 0<=lane<32 or not 0<=addr<4096:raise ValueError('address fields')
    return (sel<<31)|(lane<<21)|(layer<<16)|addr

def validate_requant_coverage(records):
    """Reject missing or duplicate model records; weight RAM geometry is separate."""
    seen=set();rq=set()
    for record in records:
        sel,layer,lane,addr=record.fields()
        if record.address in seen:raise ValueError('duplicate record address')
        seen.add(record.address)
        if not sel:rq.add((layer,addr))
    expected={(layer,a) for layer,n in enumerate(COUT) for a in list(range(3*n))+list(range(META_BASE,META_BASE+3))}
    if rq!=expected:raise ValueError('requant coverage incomplete')

def build(records,profile,model_tag=(0,0)):
    records=list(records);validate_requant_coverage(records)
    if not 0<profile<2**32:raise ValueError('nonzero hardware profile required')
    payload=b''.join(r.bytes() for r in records);size=HEADER.size+len(payload)
    if size>MAX_BYTES:raise ValueError('weight container too large')
    h=[MAGIC,VERSION,HEADER.size,size,len(records),3,13,profile,zlib.crc32(payload),0,640,480,1,*model_tag,0]
    if len(h)!=16:raise ValueError('model tag must contain two words')
    h[9]=zlib.crc32(HEADER.pack(*h))
    return HEADER.pack(*h)+payload

def parse(blob,expected_profile):
    if not HEADER.size<=len(blob)<=MAX_BYTES:raise ValueError('container length')
    h=list(HEADER.unpack_from(blob));header_crc=h[9];h[9]=0
    if zlib.crc32(HEADER.pack(*h))!=header_crc:raise ValueError('header CRC32')
    if h[:3]!=[MAGIC,VERSION,HEADER.size]:raise ValueError('container version')
    if h[3]!=len(blob) or h[3]!=HEADER.size+h[4]*RECORD.size:raise ValueError('declared length')
    if h[5:8]!=[3,13,expected_profile]:raise ValueError('incompatible hardware profile')
    if h[10:13]!=[640,480,1] or h[15]:raise ValueError('dimensions/flags/reserved')
    payload=blob[HEADER.size:]
    if zlib.crc32(payload)!=h[8]:raise ValueError('payload CRC32')
    records=[]
    for a,lo,hi in RECORD.iter_unpack(payload):
        if hi>=64:raise ValueError('record high bits')
        records.append(Record(a,lo|(hi<<32)))
    validate_requant_coverage(records)
    return dict(version=h[1],bytes=h[3],records=records,profile=h[7],payload_crc32=h[8],model_tag=h[13:15])
