"""Synchronize final evidence, verify identity, and archive the measured delivery."""
import datetime
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / 'DELIVERY_20261026_C48'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert DEST.is_dir()
    archive = ROOT / (DEST.name + '.zip')
    assert not archive.exists(), 'Preserve existing archive; use a new delivery version.'
    for name in ['FINAL_DELIVERY_20261026.md', 'WEIGHT_SWAP_GUIDE.md',
                 'FREEZE_QAT_20261026.md', 'DYNAMIC_REQUANT_DESIGN.md']:
        shutil.copy2(ROOT / 'reports' / name, DEST / 'reports' / name)
    shutil.copy2(ROOT / 'STATUS.md', DEST / 'STATUS.md')
    for name in ['inspect_c48_package.py', 'package_delivery.py', 'finalize_delivery.py',
                 'measure_rtl_throughput.py', 'analyze_rtl_throughput.py']:
        shutil.copy2(ROOT / 'src' / name, DEST / 'src' / name)
    readme = DEST / 'README.md'
    text = readme.read_text(encoding='utf-8')
    text = text.replace(
        '实际固件编译命令与ROM生成记录见hardware/board/validation/firmware_build.log。',
        '固件构建入口为hardware/board/embedded_sw/soc/software/standalone/stylecam/build_fw.py，具体命令见该脚本；构建输出及容量记录见hardware/board/validation/firmware_build.log。')
    if 'src/inspect_c48_package.py' not in text:
        text += '\n仅检查包的CRC、profile、完整布局和各风格元数据：`python -B src/inspect_c48_package.py weights/model.bin`。\n'
    readme.write_text(text, encoding='utf-8')
    diagnostic = ROOT / 'out/rtl_throughput_640x64'
    if (diagnostic / 'result.json').exists():
        target = DEST / 'evidence/rtl_throughput_640x64'
        target.mkdir(exist_ok=True, parents=True)
        for p in diagnostic.rglob('*'):
            if p.is_file() and (p.suffix in ['.json', '.log', '.sv'] or 'rtl_snapshot' in p.parts):
                to = target / p.relative_to(diagnostic)
                to.parent.mkdir(exist_ok=True, parents=True)
                shutil.copy2(p, to)
    manifest_path = DEST / 'manifest.json'
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    # The original assembler inventoried the whole staging model directory,
    # including unused v21b tables. Preserve them as historical evidence only.
    active_model = {'camera_gamma.mem', 'font8x16.mem', 'osd_text.mem', 'net_blob.bin'}
    inherited = manifest.setdefault('excluded_inherited_model_inventory_sha256', {})
    for name, expected in list(manifest['build_input_sha256'].items()):
        rel = Path(name)
        if rel.parts[0] == 'model' and rel.name not in active_model:
            source = ROOT / 'hardware/build' / rel
            assert sha(source) == expected, name
            historical = DEST / 'evidence/inherited_v21b_model_inventory' / rel.name
            historical.parent.mkdir(parents=True, exist_ok=True)
            delivered = DEST / 'hardware/board' / rel
            if delivered.exists():
                shutil.move(str(delivered), str(historical))
            else:
                shutil.copy2(source, historical)
            inherited[name] = expected
            del manifest['build_input_sha256'][name]
    if inherited:
        (DEST / 'evidence/inherited_v21b_model_inventory/README.md').write_text(
            '# 历史暂存目录清单\n\n这些是原板级暂存目录继承的v21b表和旧清单，不是本次C48模型，未被本次C48网络引用，不得上板当作选定权重。仅为解释原构建目录清单而保存。当前模型以weights/model.bin及manifest.json为准。\n', encoding='utf-8')
    for name, expected in manifest['build_input_sha256'].items():
        assert sha(DEST / 'hardware/board' / name) == expected, name
    for name, expected in manifest['rtl_real_weight_regression']['source_sha256'].items():
        assert sha(DEST / name) == expected, name
    model_sha = sha(DEST / 'weights/model.bin')
    assert model_sha == 'd214f4d2d67a21f28f3785aebe9c5ce16be0afa9d8950eebc5faaa02c8fa0cc3'
    assert sha(DEST / 'hardware/board/model/net_blob.bin') == model_sha
    assert sha(DEST / 'portable_export/model.bin') == model_sha
    for ext in ['bit', 'hex']:
        assert sha(DEST / f'bitstream/tristyle_c48.{ext}') == sha(ROOT / f'hardware/build/outflow/ti60f225_oob.{ext}')
    manifest['finalized_at'] = datetime.datetime.now().astimezone().isoformat()
    manifest['selected_blob_sha256'] = model_sha
    if (diagnostic / 'result.json').exists():
        manifest['rtl_throughput_diagnostic'] = json.loads((diagnostic / 'result.json').read_text())
        manifest['rtl_throughput_analysis'] = json.loads((diagnostic / 'analysis.json').read_text())
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    checksum_file = DEST / 'SHA256SUMS.json'
    checks = {p.relative_to(DEST).as_posix(): sha(p) for p in sorted(DEST.rglob('*'))
              if p.is_file() and p != checksum_file}
    checksum_file.write_text(json.dumps(checks, indent=2), encoding='utf-8')
    assert all(sha(DEST / p) == expected for p, expected in checks.items())
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in sorted(DEST.rglob('*')):
            if p.is_file():
                z.write(p, (Path(DEST.name) / p.relative_to(DEST)).as_posix())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(checks) + 1
        for name in ['weights/model.bin', 'bitstream/tristyle_c48.bit', 'README.md',
                     'reports/FINAL_DELIVERY_20261026.md', 'src/inspect_c48_package.py']:
            assert f'{DEST.name}/{name}' in z.namelist()
    archive_sha = sha(archive)
    archive.with_suffix('.zip.sha256').write_text(f'{archive_sha}  {archive.name}\n', encoding='ascii')
    summary = dict(finalized_at=manifest['finalized_at'], archive=str(archive),
                   archive_sha256=archive_sha, bytes=archive.stat().st_size,
                   files=len(checks) + 1, all_file_hashes_verified=True,
                   zip_crc_verified=True, build_and_regression_identity_verified=True,
                   board_verified=False)
    (ROOT / 'reports/DELIVERY_ARCHIVE_VERIFICATION.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
