"""Full 13-layer RTL vs independent CPU integer reference, external bus loads.

Default data is explicitly synthetic. --blob enables actual exported model data.
"""
import argparse,hashlib,json,os,subprocess,time
from pathlib import Path
import numpy as np
from PIL import Image,ImageOps
from c48_hardware_profile import LAYERS,PROFILE,export_blob,load_blob
from dynamic_requant_contract import RequantMeta
from integer_c48 import run
ROOT=Path(__file__).resolve().parents[1];RTL=ROOT/'hardware/rtl'
BIN=Path(r'D:\fpga\tristyle_fresh_20261016\external_runtime\icarus\mingw64\bin')

def hex_lines(path,words,width):path.write_text(''.join(f'{int(w):0{width}x}\n' for w in words))

def synthetic_model(seed):
    rng=np.random.default_rng(seed);layers=[]
    for l in LAYERS:
        weight=rng.integers(-8,9,(l.cout,1 if l.dw else l.cin,l.kernel,l.kernel),dtype=np.int8)
        m=rng.integers(1,12,(3,l.cout),dtype=np.int64)
        m[:,::7]*=-1
        b=rng.integers(60*256,140*256,(3,l.cout),dtype=np.int64)
        meta=[RequantMeta(sid,10+sid,8,(1<<(8+sid)) if l.skip else 0) for sid in range(3)]
        layers.append(dict(weight=weight,m=m,bq=b,meta=meta))
    return layers

def testbench(w,h,nfr,nw):
    lines=['`timescale 1ns/1ps','module tb;',f'localparam W={w},H={h},NFR={nfr},NP=W*H;',
      'reg clk=0,rst=1;always #5 clk=~clk;',
      'reg [3:0] style=0;reg cw=0,cs=0;reg [4:0] cl=0,cn=0;reg [11:0] ca=0;reg [37:0] cd=0;',
      'reg [23:0] id=0;reg iv=0;wire ir;wire [23:0] od;wire ov;reg ready=0;',
      'integer frame=0,ip,op=0,cycle=0,cf,rc,ncfg;reg [31:0] address,lo,hi;',
      'reg [23:0] inputs[0:NFR*NP-1],expected[0:NFR*NP-1];',
      "stylenet_top #(.WIDTH(W),.HEIGHT(H)) dut(.clk(clk),.rst(rst),.style(style),",
      '.cfg_we(cw),.cfg_sel(cs),.cfg_layer(cl),.cfg_lane(cn),.cfg_addr(ca),.cfg_data(cd),',
      ".i_data(id),.i_valid(iv),.i_ready(ir),.o_data(od),.o_valid(ov),.o_ready(ready),",
      ".st_sel(5'd0),.st_arm(1'b0),.st_fs(1'b0),.st_fe(1'b0),.st_idx(8'd0),.st_s1(),.st_s2(),.st_done(),.st_busy());",
      'always @(negedge clk)begin cycle=cycle+1;ready=(cycle%13<9)&&(cycle%47>3);end',
      'always @(posedge clk)if(!rst&&ov&&ready)begin',
      ' if(op>=NP)$fatal(1,"EXCESS_OUTPUT frame=%0d",frame);',
      ' if(od!==expected[frame*NP+op])$fatal(1,"FINAL_MISMATCH frame=%0d pixel=%0d got=%h expected=%h",frame,op,od,expected[frame*NP+op]);',
      ' op=op+1;end']
    for i,n in enumerate(nw):
        lines += [f'integer lc{i}=0;reg [31:0] e{i}[0:NFR*{n}-1];',
                  f'always @(posedge clk)if(!rst&&dut.v{i}&&dut.r{i})begin',
                  f' if(lc{i}>={n})$fatal(1,"LAYER_EXCESS layer={i}");',
                  f' if(dut.d{i}!==e{i}[frame*{n}+lc{i}])$fatal(1,"LAYER_MISMATCH layer={i} frame=%0d word=%0d got=%h expected=%h",frame,lc{i},dut.d{i},e{i}[frame*{n}+lc{i}]);',
                  f' lc{i}=lc{i}+1;end']
    lines += ['task load_config(input integer p);begin',
      ' cf=$fopen(p==0?"cfg0.txt":"cfg1.txt","r");if(!cf)$fatal(1,"CONFIG_OPEN");ncfg=0;',
      r' while(!$feof(cf))begin @(negedge clk);rc=$fscanf(cf,"%h %h %h\n",address,lo,hi);',
      ' if(rc==3)begin cs=address[31];cl=address[20:16];cn=address[25:21];ca=address[11:0];cd={hi[5:0],lo};cw=1;ncfg=ncfg+1;',
      ' @(negedge clk);cw=0;repeat(2)@(negedge clk);end end $fclose(cf);',
      ' $display("LOADED package=%0d records=%0d",p,ncfg);end endtask',
      'initial begin',
      ' $readmemh("input.hex",inputs);$readmemh("expected.hex",expected);']
    for i in range(13):lines.append(f' $readmemh("layer{i}.hex",e{i});')
    lines += [' repeat(5)@(negedge clk);rst=0;',
      ' for(frame=0;frame<NFR;frame=frame+1)begin',
      ' if(frame%3==0)load_config(frame/3);',
      ' @(negedge clk);rst=1;iv=0;repeat(4)@(negedge clk);op=0;']
    lines += [f' lc{i}=0;' for i in range(13)]
    lines += [' style=frame%3;rst=0;',
      ' for(ip=0;ip<NP;ip=ip+1)begin',
      ' @(negedge clk);iv=1;id=inputs[frame*NP+ip];@(posedge clk);while(!ir)@(posedge clk);',
      ' @(negedge clk);iv=0;if(ip%17==0)repeat(2)@(negedge clk);end',
      ' wait(op==NP);repeat(16)@(negedge clk);']
    lines += [f' if(lc{i}!={n})$fatal(1,"LAYER_MISSING layer={i}");' for i,n in enumerate(nw)]
    lines += [' $display("FRAME_PASS frame=%0d style=%0d cycles=%0d",frame,style,cycle);end',
      ' $display("PASS C48_FULL_NETWORK_0_LSB");$finish;end',
      'initial begin #2000000000;$fatal(1,"TIMEOUT");end','endmodule']
    return '\n'.join(lines)+'\n'

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--blob',type=Path);ap.add_argument('--image',type=Path)
    ap.add_argument('--width',type=int,default=32);ap.add_argument('--height',type=int,default=24)
    ap.add_argument('--out',type=Path);ap.add_argument('--timeout',type=int,default=120)
    args=ap.parse_args();w,h=args.width,args.height;assert w%4==0 and h%4==0
    out=(args.out or ROOT/'out/c48_network_synthetic').resolve();out.mkdir(parents=True,exist_ok=True)
    t0=time.time();blobs=[args.blob.read_bytes()] if args.blob else [export_blob(synthetic_model(seed)) for seed in (480,481)]
    inputs=[];outputs=[];inter=[[] for _ in LAYERS];models=[]
    for p,blob in enumerate(blobs):
        layers,header=load_blob(blob);models.append(layers)
        (out/f'package{p}.bin').write_bytes(blob)
        (out/f'cfg{p}.txt').write_text(''.join(f'{r.address:08x} {r.data&0xffffffff:08x} {r.data>>32:02x}\n' for r in header['records']))
        if not args.blob:
            original=synthetic_model(480+p)
            for q,r in zip(original,layers):
                for key in ('weight','m','bq'):assert np.array_equal(q[key],r[key])
                assert q['meta']==r['meta']
        for sid in range(3):
            if args.image:im=np.array(ImageOps.fit(Image.open(args.image).convert('RGB'),(w,h),method=Image.Resampling.LANCZOS))
            else:im=np.random.default_rng(2000+p*3+sid).integers(0,256,(h,w,3),dtype=np.uint8)
            y,trace=run(layers,im,sid,trace=True);inputs.append(im);outputs.append(y)
            for i,a in enumerate(trace):inter[i].append(a)
    nfr=len(inputs);rgbwords=lambda a:(a[...,0].astype(np.uint32)|(a[...,1].astype(np.uint32)<<8)|(a[...,2].astype(np.uint32)<<16)).flatten()
    hex_lines(out/'input.hex',np.concatenate([rgbwords(a) for a in inputs]),6)
    hex_lines(out/'expected.hex',np.concatenate([rgbwords(a) for a in outputs]),6)
    nw=[]
    for i,frames in enumerate(inter):
        words=[]
        for a in frames:
            aa=a.transpose(1,2,0).reshape(-1,4).astype(np.uint32)
            words.append(aa[:,0]|(aa[:,1]<<8)|(aa[:,2]<<16)|(aa[:,3]<<24))
        nw.append(len(words[0]));hex_lines(out/f'layer{i}.hex',np.concatenate(words),8)
    (out/'tb.sv').write_text(testbench(w,h,nfr,nw))
    sources=[RTL/n for n in ['common.v','packed_line_ram.v','mac.v','swg3.v','swg3b.v','requant.v','conv_layer.v','stylenet_top.v']]
    # Bind evidence to the files actually compiled, even during another RTL edit.
    source_hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources+[Path(__file__),ROOT/'src/integer_c48.py',ROOT/'src/c48_hardware_profile.py']}
    snapshot=out/'rtl_snapshot';snapshot.mkdir(exist_ok=True)
    for p in sources:(snapshot/p.name).write_bytes(p.read_bytes())
    sources=[snapshot/p.name for p in sources]
    env=os.environ.copy();env['PATH']=str(BIN)+';'+env['PATH']
    c=subprocess.run([str(BIN/'iverilog.exe'),'-g2012','-s','tb','-o','sim.vvp','tb.sv',*map(str,sources)],cwd=out,env=env,capture_output=True,text=True)
    (out/'compile.log').write_text(c.stdout+c.stderr);assert c.returncode==0,c.stderr
    print('FULL_SIM_START',w,h,nfr,round(time.time()-t0,2),flush=True)
    v=subprocess.run([str(BIN/'vvp.exe'),'sim.vvp'],cwd=out,env=env,capture_output=True,text=True,timeout=args.timeout)
    (out/'simulation.log').write_text(v.stdout+v.stderr);print(v.stdout,flush=True)
    assert v.returncode==0 and 'PASS C48_FULL_NETWORK_0_LSB' in v.stdout
    result=dict(passed=True,scope='Full 13-layer RTL and CPU integer reference; synthetic weights' if not args.blob else 'Full 13-layer RTL and CPU integer reference; supplied exported weights',
                synthetic=not bool(args.blob),qat_verified=False,board_verified=False,
                size=[w,h],styles=3,frames=nfr,parameter_packages=len(blobs),profile=PROFILE,
                max_lsb_error=0,layer_words=sum(nw)*nfr,final_pixels=w*h*nfr,backpressure=True,
                reset_between_frames=True,seconds=time.time()-t0,
                blob_sha256=[hashlib.sha256(b).hexdigest() for b in blobs],
                source_sha256=source_hashes)
    (out/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

if __name__=='__main__':main()
