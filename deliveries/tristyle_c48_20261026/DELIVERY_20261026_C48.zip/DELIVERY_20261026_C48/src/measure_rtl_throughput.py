"""RTL timing diagnostic only: no image equality or board FPS claim."""
import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
BIN=Path(r'D:\fpga\tristyle_fresh_20261016\external_runtime\icarus\mingw64\bin')
OUT=ROOT/'out/rtl_throughput_640x64'
OUT.mkdir(exist_ok=False)
names=['common.v','packed_line_ram.v','mac.v','swg3.v','swg3b.v','requant.v','conv_layer.v','stylenet_top.v']
snap=OUT/'rtl_snapshot';snap.mkdir()
for n in names:shutil.copy2(ROOT/'hardware/rtl'/n,snap/n)
shutil.copy2(ROOT/'out/c48_network_qat1800_opt2_w640/cfg0.txt',OUT/'cfg.txt')
tb=r'''`timescale 1ns/1ps
module tb;
localparam W=640,H=64,NP=W*H;
reg clk=0,rst=1;always #5 clk=~clk;
reg cw=0,cs=0;reg [4:0] cl=0,cn=0;reg [11:0] ca=0;reg [37:0] cd=0;
reg [23:0] id=0;reg iv=0;wire ir;wire [23:0] od;wire ov;
integer ip=0,op=0,cycle=0,start_cycle=0,first_cycle=0,fd,rc,count=0;
reg [31:0] address,lo,hi;
stylenet_top #(.WIDTH(W),.HEIGHT(H)) dut(.clk(clk),.rst(rst),.style(4'd0),
.cfg_we(cw),.cfg_sel(cs),.cfg_layer(cl),.cfg_lane(cn),.cfg_addr(ca),.cfg_data(cd),
.i_data(id),.i_valid(iv),.i_ready(ir),.o_data(od),.o_valid(ov),.o_ready(1'b1),
.st_sel(5'd0),.st_arm(1'b0),.st_fs(1'b0),.st_fe(1'b0),.st_idx(8'd0),.st_s1(),.st_s2(),.st_done(),.st_busy());
always @(posedge clk)begin
cycle=cycle+1;
if(!rst&&iv&&ir)ip=ip+1;
if(!rst&&ov)begin
if(op==0)begin first_cycle=cycle;$display("FIRST %0d",cycle-start_cycle);$fflush();end
op=op+1;
if(op%W==0)begin $display("ROW %0d %0d",op/W,cycle-start_cycle);$fflush();end
if(op==NP)begin $display("DONE cycles=%0d first=%0d pixels=%0d",cycle-start_cycle,first_cycle-start_cycle,op);$finish;end
end
end
always @(negedge clk)begin
if(!rst&&count==6951)begin iv=ip<NP;id=24'h479bc3+ip;end
end
initial begin
repeat(5)@(negedge clk);rst=0;
fd=$fopen("cfg.txt","r");if(!fd)$fatal;
while(!$feof(fd))begin
@(negedge clk);rc=$fscanf(fd,"%h %h %h\n",address,lo,hi);
if(rc==3)begin cs=address[31];cl=address[20:16];cn=address[25:21];ca=address[11:0];cd={hi[5:0],lo};cw=1;
@(negedge clk);cw=0;repeat(2)@(negedge clk);end
end
$fclose(fd);@(negedge clk);rst=1;repeat(4)@(negedge clk);rst=0;start_cycle=cycle;count=6951;
end
initial begin #2000000000;$fatal(1,"TIMEOUT");end
endmodule
'''
(OUT/'tb.sv').write_text(tb)
env=os.environ.copy();env['PATH']=str(BIN)+';'+env['PATH']
t0=time.time()
c=subprocess.run([str(BIN/'iverilog.exe'),'-g2012','-s','tb','-o','sim.vvp','tb.sv',*[str(snap/n) for n in names]],cwd=OUT,env=env,capture_output=True,text=True)
(OUT/'compile.log').write_text(c.stdout+c.stderr);assert c.returncode==0,c.stderr
print('THROUGHPUT_START',flush=True)
try:
 with (OUT/'simulation.log').open('w') as f:
  v=subprocess.run([str(BIN/'vvp.exe'),'sim.vvp'],cwd=OUT,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=720)
except subprocess.TimeoutExpired:
 result=dict(scope='640x64 RTL throughput diagnostic; NOT full-frame or board FPS',
  completed=False,reason='720 second wall-clock simulation timeout; no throughput conclusion',
  seconds=time.time()-t0,board_verified=False,
  source_sha256={n:hashlib.sha256((snap/n).read_bytes()).hexdigest() for n in names})
 (OUT/'result.json').write_text(json.dumps(result,indent=2))
 print(json.dumps(result,indent=2),flush=True)
 raise SystemExit(2)
log=(OUT/'simulation.log').read_text();print(log[-2500:],flush=True)
assert v.returncode==0 and 'DONE cycles=' in log
rows=[list(map(int,s.split()[1:])) for s in log.splitlines() if s.startswith('ROW ')]
delta=rows[-1][1]-rows[-17][1]
result=dict(scope='640x64 RTL throughput diagnostic, always-ready output; NOT full-frame or board FPS',completed=True,
 size=[640,64],clock_hz=150000000,rows=rows,last_16_rows_cycles=delta,
 extrapolated_480row_steady_fps=150e6/(delta*30),
 source_sha256={n:hashlib.sha256((snap/n).read_bytes()).hexdigest() for n in names},
 blob_sha256=hashlib.sha256((ROOT/'out/qat_c48/model_01800.bin').read_bytes()).hexdigest(),
 seconds=time.time()-t0,board_verified=False)
(OUT/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
